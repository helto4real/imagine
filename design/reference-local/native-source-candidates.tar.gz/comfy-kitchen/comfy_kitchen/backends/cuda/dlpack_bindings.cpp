/*
 * SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include <nanobind/nanobind.h>
#include <nanobind/ndarray.h>
#include <nanobind/stl/optional.h>
#include <cuda_runtime.h>
#include <climits>
#include <cstring>
#include <optional>
#include <tuple>

#include "cublaslt_runtime.h"
#include "input_act_codes.h"

namespace nb = nanobind;

// Helper: Map nanobind dtype to internal dtype code
// Returns: 0=float32, 1=float16, 2=bfloat16, 3=uint8, 4=int8, 5=float8_e4m3fn, 6=float8_e5m2
int map_dtype_to_code(const nb::dlpack::dtype& dtype) {
    if (dtype.code == (uint8_t)nb::dlpack::dtype_code::Float) {
        if (dtype.bits == 32) return 0;  // float32
        if (dtype.bits == 16) return 1;  // float16
        if (dtype.bits == 8) return 5;   // float8_e4m3fn (default)
    } else if (dtype.code == (uint8_t)nb::dlpack::dtype_code::Bfloat && dtype.bits == 16) {
        return 2;  // bfloat16
    } else if (dtype.code == (uint8_t)nb::dlpack::dtype_code::UInt && dtype.bits == 8) {
        return 3;  // uint8
    } else if (dtype.code == (uint8_t)nb::dlpack::dtype_code::Int && dtype.bits == 8) {
        return 4;  // int8
    }
    return -1;  // unsupported
}

// Forward declarations of CUDA kernel wrappers
extern "C" {
    void launch_quantize_fp8_kernel(const void* input, void* output, 
                                    const void* scale, int64_t numel,
                                    int input_dtype_code, int output_dtype_code,
                                    cudaStream_t stream);
    
    void launch_dequantize_fp8_kernel(const void* input, void* output,
                                      const void* scale, int64_t numel,
                                      int input_dtype_code, int output_dtype_code,
                                      cudaStream_t stream);

    void launch_stochastic_round_fp8_kernel(void* rng_and_output,
                                            const void* input,
                                            int64_t numel,
                                            int rng_dtype_code,
                                            int input_dtype_code,
                                            int output_dtype_code,
                                            cudaStream_t stream);

    void launch_cublas_gemm_blockwise_fp4_kernel(
        const void* B_ptr,
        const void* B_decode_scale_ptr,
        const void* A_ptr,
        const void* A_decode_scale_ptr,
        void* D_ptr,
        const void* bias_ptr,
        int64_t M,
        int64_t N,
        int64_t K,
        const float* alpha_device_ptr,
        int out_dtype_code,
        void* workspace_ptr,
        bool accumulate,
        cudaStream_t stream);

    void launch_apply_rope_kernel(
        const void* xq,
        const void* xk,
        const void* freqs,
        void* xq_out,
        void* xk_out,
        int64_t batch,
        int64_t dim1,
        int64_t dim2,
        int64_t head_dim,
        int64_t freqs_batch,
        int64_t freqs_dim1,
        int64_t freqs_dim2,
        int64_t q_s0, int64_t q_s1, int64_t q_s2, int64_t q_s3,
        int64_t k_s0, int64_t k_s1, int64_t k_s2, int64_t k_s3,
        int64_t qo_s0, int64_t qo_s1, int64_t qo_s2, int64_t qo_s3,
        int64_t ko_s0, int64_t ko_s1, int64_t ko_s2, int64_t ko_s3,
        int64_t stride_freqs_batch,
        int64_t stride_freqs_dim1,
        int64_t stride_freqs_dim2,
        int64_t stride_freqs_dim,
        int64_t stride_freqs_rot,
        int64_t stride_freqs_pair,
        int input_dtype_code,
        int freqs_dtype_code,
        bool has_k,
        bool split_half,
        cudaStream_t stream);

    void launch_quantize_nvfp4_kernel(
        const void* input,
        const void* global_scale,
        void* output,
        void* block_scales,
        int64_t num_rows,
        int64_t num_cols,
        int64_t orig_rows,
        int64_t orig_cols,
        float epsilon,
        int input_dtype_code,
        bool hi_first,
        cudaStream_t stream);

    void launch_rms_rope_kernel(
        const void* q,
        const void* k,
        const void* freqs,
        const void* q_scale,
        const void* k_scale,
        void* q_out,
        void* k_out,
        int64_t batch, int64_t dim1, int64_t dim2, int64_t head_dim,
        int64_t rot_dim,
        int64_t freqs_batch, int64_t freqs_dim1, int64_t freqs_dim2,
        int64_t q_s0, int64_t q_s1, int64_t q_s2, int64_t q_s3,
        int64_t k_s0, int64_t k_s1, int64_t k_s2, int64_t k_s3,
        int64_t qo_s0, int64_t qo_s1, int64_t qo_s2, int64_t qo_s3,
        int64_t ko_s0, int64_t ko_s1, int64_t ko_s2, int64_t ko_s3,
        int64_t f_s0, int64_t f_s1, int64_t f_s2, int64_t f_s3,
        int64_t f_s4, int64_t f_s5, int64_t qs_stride,
        int64_t ks_stride,
        float epsilon,
        int input_dtype_code,
        int freqs_dtype_code,
        int scale_dtype_code,
        bool has_k,
        bool split_half,
        cudaStream_t stream);

    void launch_dequantize_nvfp4_kernel(
        const void* input,
        const void* global_scale,
        const void* block_scales,
        void* output,
        int64_t num_rows,
        int64_t num_cols,
        int output_dtype_code,
        bool hi_first,
        cudaStream_t stream);

    void launch_quantize_mxfp8_kernel(
        const void* input,
        void* output,
        void* block_scales,
        int64_t num_rows,
        int64_t num_cols,
        int64_t orig_rows,
        int64_t orig_cols,
        int input_dtype_code,
        cudaStream_t stream);

    // SageAttention kernel launchers
    void launch_quant_qk_per_thread_int8(
        const void* q, void* q_int8, void* q_scale,
        const void* k, void* k_int8, void* k_scale,
        int B, int H_q, int Lq, int H_kv, int Lk, int C,
        int BLKQ, int WARPQ, int BLKK, int WARPK,
        int64_t q_stride_b, int64_t q_stride_h, int64_t q_stride_n,
        int64_t k_stride_b, int64_t k_stride_h, int64_t k_stride_n,
        int input_dtype_code, void* anchor_indices, cudaStream_t stream);

    void launch_quant_v_int8_kernel(
        const void* v, void* out, void* scale,
        int B, int H, int N, int D, int padded_N,
        int64_t sb, int64_t sh, int64_t sn,
        int input_dtype_code, cudaStream_t stream);

    void launch_sage_attn_kernel(
        const void* q, const void* k, const void* v, void* o,
        const void* q_scale, const void* k_scale, const void* v_scale,
        const void* mask, int64_t mask_stride_b, int64_t mask_stride_h,
        int64_t mask_stride_q, int64_t mask_stride_k, int mask_dtype_code,
        int cta_k, int B, int Lq, int Lk, int H_q, int H_kv, int D,
        int64_t q_st_bz, int q_st_n, int64_t q_st_h,
        int64_t k_st_bz, int k_st_n, int64_t k_st_h,
        int64_t v_st_bz, int64_t v_st_h, int v_st_d,
        int64_t o_st_bz, int o_st_n, int64_t o_st_h,
        float sm_scale, int output_dtype_code, cudaStream_t stream, const float *mask_tile_bias = nullptr);

    void launch_sage_prepare_key_mask(
        const void *mask, float *packed, int batch, int heads, int length,
        int64_t stride_b, int64_t stride_h, int64_t stride_k,
        int dtype_code, cudaStream_t stream);

    // SVDQuant W4A4 — see ops/quantize_svdquant_w4a4.cu
    void launch_svdquant_quantize_w4a4_kernel(
        const void* x,
        const void* smooth,
        const void* lora_down,
        void* q_x,
        void* ascales,
        void* lora_act,
        int M,
        int M_pad,
        int K,
        int R,
        int input_dtype_code,
        int act_unsigned,
        cudaStream_t stream);

    // SVDQuant W4A4 — see ops/scaled_mm_svdquant_w4a4.cu
    void launch_svdquant_scaled_mm_w4a4_kernel(
        const void* act,
        const void* wgt,
        const void* ascales,
        const void* wscales,
        const void* lora_act_in,
        const void* lora_up,
        const void* bias,
        void* out,
        int M,
        int N,
        int K,
        int R,
        int act_unsigned,
        int out_dtype_code,
        int tile_packed,
        int fast_accum,
        int shared_scale,
        int fuse_lora,
        cudaStream_t stream);

    // AWQ W4A16 — see ops/awq_w4a16.cu. Internal M-routing picks
    // gemv (M ≤ 8) vs gemm path; bias / LoRA-up are applied externally.
    void launch_awq_w4a16_kernel(
        const void* x,
        const void* qweight,
        const void* wscales,
        const void* wzeros,
        void* out,
        int M,
        int N,
        int K,
        int G,
        int dtype_code,
        cudaStream_t stream);

    // Fused 3D neighborhood attention — see ops/na3d.cu.
    void launch_na3d_kernel(
        const void* q, const void* k, const void* v, void* out,
        int batch, int t_size, int h_size, int w_size, int num_heads, int head_dim,
        int kt, int kh, int kw,
        int causal_t, int causal_h, int causal_w,
        float scale, int dtype_code, cudaStream_t stream);

    // Sol-Attn sparse attention — see sage_attention/sol_attn.cu.
    extern const char* const sol_attn_plan_names[];   // null-terminated
    int sol_attn_plan(int batch, int seq_len, int num_heads, int n_tok, int64_t* out, int cap);
    void sol_producer_begin(void* workspace, int batch, int seq_len,
                            int num_heads, int n_tok, cudaStream_t stream);
    void sol_producer_chunk(
        void* workspace, const void* qkv, const void* fab,
        const void* qw, const void* kw, const void* kmean, const void* vscale,
        const void* blen, float rope_eps, int rot_dim, int t0, int M,
        int batch, int seq_len, int num_heads, int n_tok, cudaStream_t stream);
    void launch_sol_attn_core(
        void* workspace, void* out, const void* vscale, void* kmean_next, void* vamax_out,
        const void* blen, int tail,
        int batch, int seq_len, int num_heads,
        float tau, float scale, const void* ext_threshold,
        int sink_start, int sink_end, int sink_q_start, int sink_q_end,
        int n_tok, cudaStream_t stream);
    void launch_sol_attn(
        const void* q, const void* k, const void* v, void* out, void* workspace,
        int batch, int seq_len, int num_heads, int head_dim, int elem,
        float tau, float scale, const void* key_bias,
        const void* ext_threshold, const void* blen, int tail,
        int sink_start, int sink_end, int sink_q_start, int sink_q_end,
        int64_t qs_b, int64_t qs_t, int64_t qs_h,
        int64_t ks_b, int64_t ks_t, int64_t ks_h,
        int64_t vs_b, int64_t vs_t, int64_t vs_h,
        int n_tok, cudaStream_t stream);

    // fp16-accumulate NDHWC conv3d with fused bias/residual — see ops/cutlass_conv3d_fp16.cu.
    // resid is a full NZPQK tensor (resid_full) or a K-vector broadcast to every row.
    bool launch_cutlass_fp16_conv3d(
        const void* x, const void* w, const void* bias, const void* resid, bool resid_full, void* out,
        int N, int D, int H, int W, int C, int K, int T, int R, int S, int Z, int P, int Q,
        int sd, int sh, int sw, int config,
        int xs_w, int xs_h, int xs_d, int xs_n, int os_w, int os_h, int os_d, int os_n,
        cudaStream_t stream);

    // Per-frame GroupNorm + SiLU + causal conv padding in NDHWC — see ops/group_norm_pad3d.cu.
    void launch_group_norm_silu_pad3d(
        const void* x, const void* gamma, const void* beta, void* out, void* workspace,
        int B, int C, int T, int H, int W, int G, float eps,
        int left, int right, int top, int bottom, int front, bool silu, bool zero_pad,
        int dtype_code, cudaStream_t stream);

    // Fused AdaLN — see ops/adaln.cu. subtract_mean selects LayerNorm (true)
    // or RMSNorm (false) statistics.
    void launch_adaln_kernel(
        const void* x,
        const void* scale,
        const void* shift,
        void*       out,
        int64_t     N,
        int64_t     D,
        int64_t     scale_group,
        int64_t     shift_group,
        float       eps,
        int         dtype_code,
        bool        subtract_mean,
        cudaStream_t stream);
}

// Nanobind wrapper for quantize_per_tensor_fp8
void quantize_per_tensor_fp8(
    nb::ndarray<nb::device::cuda> input,
    nb::ndarray<nb::device::cuda> scale,
    nb::ndarray<nb::device::cuda> output,
    int input_dtype_code,
    int output_dtype_code,
    int64_t numel,
    uintptr_t stream_ptr) {
    
    // Validate input dtype code (0=float32, 1=float16, 2=bfloat16)
    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error("Unsupported input dtype for quantize_per_tensor_fp8");
    }
    
    // Validate output dtype code (5=e4m3fn, 6=e5m2)
    if (output_dtype_code < 5 || output_dtype_code > 6) {
        throw std::runtime_error("Unsupported output dtype for quantize_per_tensor_fp8");
    }
    
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quantize_fp8_kernel(input.data(), output.data(), scale.data(), 
                              numel, input_dtype_code, output_dtype_code, stream);
}

// Nanobind wrapper for dequantize_per_tensor_fp8
void dequantize_per_tensor_fp8(
    nb::ndarray<nb::device::cuda> input,
    nb::ndarray<nb::device::cuda> scale,
    nb::ndarray<nb::device::cuda> output,
    int input_dtype_code,
    int output_dtype_code,
    int64_t numel,
    uintptr_t stream_ptr) {
    
    // Validate input dtype code (5=float8_e4m3fn, 6=float8_e5m2)
    if (input_dtype_code != 5 && input_dtype_code != 6) {
        throw std::runtime_error("Unsupported input dtype code for dequantize_per_tensor_fp8 (must be 5 or 6)");
    }
    
    // Validate output dtype code (0=float32, 1=float16, 2=bfloat16)
    if (output_dtype_code < 0 || output_dtype_code > 2) {
        throw std::runtime_error("Unsupported output dtype for dequantize_per_tensor_fp8 (must be float32, float16, or bfloat16)");
    }
    
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_dequantize_fp8_kernel(input.data(), output.data(), scale.data(),
                                 numel, input_dtype_code, output_dtype_code, stream);
}

void stochastic_round_fp8(
    nb::ndarray<nb::device::cuda> rng_and_output,
    nb::ndarray<nb::device::cuda> input,
    int output_dtype_code,
    int64_t numel,
    uintptr_t stream_ptr) {

    int rng_dtype_code = map_dtype_to_code(rng_and_output.dtype());
    if (rng_dtype_code != 3) {
        throw std::runtime_error("stochastic_round_fp8 requires uint8 RNG storage");
    }

    int input_dtype_code = map_dtype_to_code(input.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error("Unsupported input dtype for stochastic_round_fp8");
    }

    if (output_dtype_code < 5 || output_dtype_code > 6) {
        throw std::runtime_error("Unsupported output dtype for stochastic_round_fp8");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_stochastic_round_fp8_kernel(
        rng_and_output.data(),
        input.data(),
        numel,
        rng_dtype_code,
        input_dtype_code,
        output_dtype_code,
        stream);
}

// Nanobind wrapper for cublas_gemm_blockwise_fp4
void cublas_gemm_blockwise_fp4(
    nb::ndarray<uint8_t, nb::ndim<2>, nb::device::cuda> b,
    nb::ndarray<uint8_t, nb::ndim<2>, nb::device::cuda> block_scale_b,
    nb::ndarray<uint8_t, nb::ndim<2>, nb::device::cuda> a,
    nb::ndarray<uint8_t, nb::ndim<2>, nb::device::cuda> block_scale_a,
    nb::ndarray<nb::device::cuda> out,
    int out_dtype_code,
    nb::ndarray<nb::device::cuda> bias,
    nb::ndarray<nb::device::cuda> workspace,
    bool accumulate,
    nb::ndarray<float, nb::device::cuda> alpha,
    uintptr_t stream_ptr) {

    auto& runtime = comfy::CublasLtRuntime::instance();
    if (!runtime.is_available()) {
        throw std::runtime_error("cuBLASLt not available: " + runtime.error_message());
    }

    // Get dimensions: B is (N, K_b), A is (M, K_a) in packed format
    int64_t N = b.shape(0);
    int64_t K_b = b.shape(1);
    int64_t M = a.shape(0);
    int64_t K_a = a.shape(1);

    if (K_a != K_b) {
        throw std::runtime_error("Matrix dimensions do not match");
    }

    // K is the number of FP4 elements (2 per uint8)
    int64_t K = 2 * K_a;

    // Validate output dtype code (0=float32, 1=float16, 2=bfloat16)
    if (out_dtype_code < 0 || out_dtype_code > 2) {
        throw std::runtime_error("Invalid output dtype code");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);

    // Handle optional bias (check if pointer is null or size is 0)
    const void* bias_ptr = (bias.data() && bias.size() > 0) ? bias.data() : nullptr;

    // Call the kernel
    launch_cublas_gemm_blockwise_fp4_kernel(
        b.data(),
        block_scale_b.data(),
        a.data(),
        block_scale_a.data(),
        out.data(),
        bias_ptr,
        M,
        N,
        K,
        static_cast<const float*>(alpha.data()),
        out_dtype_code,
        workspace.data(),
        accumulate,
        stream);
}

// Nanobind wrapper for quantize_nvfp4
void quantize_nvfp4(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<nb::device::cuda> global_scale,
    nb::ndarray<nb::device::cuda> output,
    nb::ndarray<nb::device::cuda> block_scales,
    float epsilon,
    bool pad_16x,
    bool hi_first,
    uintptr_t stream_ptr) {

    // Get input dimensions (orig_rows, orig_cols)
    int64_t orig_rows = input.shape(0);
    int64_t orig_cols = input.shape(1);

    // Calculate effective padded dimensions
    int64_t num_rows = orig_rows;
    int64_t num_cols = orig_cols;
    
    if (pad_16x) {
        // Round up to nearest multiple of 16
        num_rows = (orig_rows + 15) / 16 * 16;
        num_cols = (orig_cols + 15) / 16 * 16;
    }

    // Get input dtype code
    int input_dtype_code = map_dtype_to_code(input.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error("Unsupported input dtype for FP4 quantization (must be float32, float16, or bfloat16)");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quantize_nvfp4_kernel(
        input.data(),
        global_scale.data(),
        output.data(),
        block_scales.data(),
        num_rows,
        num_cols,
        orig_rows,
        orig_cols,
        epsilon,
        input_dtype_code,
        hi_first,
        stream);
}

// Nanobind wrapper for dequantize_nvfp4
void dequantize_nvfp4(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<nb::device::cuda> global_scale,
    nb::ndarray<nb::device::cuda> block_scales,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> output,
    int output_dtype_code,
    bool hi_first,
    uintptr_t stream_ptr) {

    // Get output dimensions (should match input logical dimensions)
    int64_t num_rows = output.shape(0);
    int64_t num_cols = output.shape(1);

    // Validate output dtype code (0=float32, 1=float16, 2=bfloat16)
    if (output_dtype_code < 0 || output_dtype_code > 2) {
        throw std::runtime_error("Unsupported output dtype for FP4 dequantization (must be float32, float16, or bfloat16)");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_dequantize_nvfp4_kernel(
        input.data(),
        global_scale.data(),
        block_scales.data(),
        output.data(),
        num_rows,
        num_cols,
        output_dtype_code,
        hi_first,
        stream);
}

// Nanobind wrapper for quantize_mxfp8
void quantize_mxfp8(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<nb::device::cuda> output,
    nb::ndarray<nb::device::cuda> block_scales,
    bool pad_32x,
    uintptr_t stream_ptr) {

    // Get input dimensions (orig_rows, orig_cols)
    int64_t orig_rows = input.shape(0);
    int64_t orig_cols = input.shape(1);

    // Calculate effective padded dimensions
    int64_t num_rows = orig_rows;
    int64_t num_cols = orig_cols;

    if (pad_32x) {
        // Round up to nearest multiple of 32
        num_rows = (orig_rows + 31) / 32 * 32;
        num_cols = (orig_cols + 31) / 32 * 32;
    }

    // Get input dtype code
    int input_dtype_code = map_dtype_to_code(input.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error("Unsupported input dtype for MXFP8 quantization (must be float32, float16, or bfloat16)");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quantize_mxfp8_kernel(
        input.data(),
        output.data(),
        block_scales.data(),
        num_rows,
        num_cols,
        orig_rows,
        orig_cols,
        input_dtype_code,
        stream);
}

// Nanobind wrapper for apply_rope (handles both single tensor and q/k pair)
void apply_rope(
    nb::ndarray<nb::device::cuda> xq,
    nb::ndarray<nb::device::cuda> freqs,
    nb::ndarray<nb::device::cuda> xq_out,
    nb::object xk_obj,
    nb::object xk_out_obj,
    uintptr_t stream_ptr,
    bool split_half = false) {

    if (xq.ndim() != 4 || freqs.ndim() != 6) {
        throw std::runtime_error("apply_rope requires a 4D input and 6D freqs");
    }
    // Get xq dimensions: (batch, dim1, dim2, head_dim) - layout agnostic
    int64_t batch = xq.shape(0);
    int64_t dim1 = xq.shape(1);
    int64_t dim2 = xq.shape(2);
    int64_t head_dim = xq.shape(3);
    if (head_dim == 0 || head_dim % 2 != 0) {
        throw std::runtime_error(
            "apply_rope requires a positive, even head dimension");
    }

    // Get freqs dimensions (for broadcasting)
    int64_t freqs_batch = freqs.shape(0);
    int64_t freqs_dim1 = freqs.shape(1);
    int64_t freqs_dim2 = freqs.shape(2);

    // Validate broadcast and trailing rotation dimensions.
    if ((freqs_batch != 1 && freqs_batch != batch) ||
        (freqs_dim1 != 1 && freqs_dim1 != dim1) ||
        (freqs_dim2 != 1 && freqs_dim2 != dim2) ||
        freqs.shape(3) != head_dim / 2 ||
        freqs.shape(4) != 2 || freqs.shape(5) != 2) {
        throw std::runtime_error("apply_rope freqs shape is not broadcastable to input");
    }

    // Validate xq_out shape matches xq
    if (xq_out.ndim() != 4 ||
        xq_out.shape(0) != batch || xq_out.shape(1) != dim1 ||
        xq_out.shape(2) != dim2 || xq_out.shape(3) != head_dim) {
        throw std::runtime_error("Output shape must match input shape");
    }

    // Handle optional xk and xk_out
    bool has_xk = !xk_obj.is_none();
    bool has_xk_out = !xk_out_obj.is_none();
    
    if (has_xk != has_xk_out) {
        throw std::runtime_error("xk and xk_out must both be provided or both be None");
    }
    
    void* xk_data = nullptr;
    void* xk_out_data = nullptr;
    int64_t k_s0 = 0, k_s1 = 0, k_s2 = 0, k_s3 = 0;
    int64_t ko_s0 = 0, ko_s1 = 0, ko_s2 = 0, ko_s3 = 0;
    
    if (has_xk) {
        auto xk = nb::cast<nb::ndarray<nb::device::cuda>>(xk_obj);
        auto xk_out = nb::cast<nb::ndarray<nb::device::cuda>>(xk_out_obj);
        
        if (xk.ndim() != 4 ||
            xk.shape(0) != batch || xk.shape(1) != dim1 ||
            xk.shape(2) != dim2 || xk.shape(3) != head_dim) {
            throw std::runtime_error("xk shape must match xq shape");
        }
        
        if (xk_out.ndim() != 4 ||
            xk_out.shape(0) != batch || xk_out.shape(1) != dim1 ||
            xk_out.shape(2) != dim2 || xk_out.shape(3) != head_dim) {
            throw std::runtime_error("xk_out shape must match xq shape");
        }
        
        xk_data = xk.data();
        xk_out_data = xk_out.data();
        k_s0 = xk.stride(0); k_s1 = xk.stride(1);
        k_s2 = xk.stride(2); k_s3 = xk.stride(3);
        ko_s0 = xk_out.stride(0); ko_s1 = xk_out.stride(1);
        ko_s2 = xk_out.stride(2); ko_s3 = xk_out.stride(3);
        if (map_dtype_to_code(xk.dtype()) != map_dtype_to_code(xq.dtype()) ||
            map_dtype_to_code(xk_out.dtype()) != map_dtype_to_code(xq.dtype())) {
            throw std::runtime_error("apply_rope inputs and outputs must share dtype");
        }
    }

    // Get input dtype code
    int input_dtype_code = map_dtype_to_code(xq.dtype());
    int output_dtype_code = map_dtype_to_code(xq_out.dtype());
    if ((input_dtype_code != 1 && input_dtype_code != 2) ||
        output_dtype_code != input_dtype_code) {
        throw std::runtime_error(
            "apply_rope inputs and outputs must share an FP16/BF16 dtype");
    }

    // Get freqs dtype code
    int freqs_dtype_code = map_dtype_to_code(freqs.dtype());
    if (freqs_dtype_code < 0 || freqs_dtype_code > 2) {
        throw std::runtime_error(
            "apply_rope frequencies must be FP32, FP16, or BF16");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);

    // Get strides (nanobind provides strides in elements, not bytes)
    int64_t stride_freqs_batch = freqs.stride(0);
    int64_t stride_freqs_dim1 = freqs.stride(1);
    int64_t stride_freqs_dim2 = freqs.stride(2);
    int64_t stride_freqs_dim = freqs.stride(3);
    int64_t stride_freqs_rot = freqs.stride(4);
    int64_t stride_freqs_pair = freqs.stride(5);

    // Launch kernel
    launch_apply_rope_kernel(
        xq.data(),
        xk_data,
        freqs.data(),
        xq_out.data(),
        xk_out_data,
        batch,
        dim1,
        dim2,
        head_dim,
        freqs_batch,
        freqs_dim1,
        freqs_dim2,
        xq.stride(0), xq.stride(1), xq.stride(2), xq.stride(3),
        k_s0, k_s1, k_s2, k_s3,
        xq_out.stride(0), xq_out.stride(1), xq_out.stride(2), xq_out.stride(3),
        ko_s0, ko_s1, ko_s2, ko_s3,
        stride_freqs_batch,
        stride_freqs_dim1,
        stride_freqs_dim2,
        stride_freqs_dim,
        stride_freqs_rot,
        stride_freqs_pair,
        input_dtype_code,
        freqs_dtype_code,
        has_xk,
        split_half,
        stream
    );
}

// Nanobind wrapper for paired fused RMSNorm + RoPE.
void rms_rope(nb::ndarray<nb::device::cuda> q, nb::ndarray<nb::device::cuda> k,
              nb::ndarray<nb::device::cuda> freqs,
              nb::ndarray<nb::device::cuda> q_scale,
              nb::ndarray<nb::device::cuda> k_scale,
              nb::ndarray<nb::device::cuda> q_out,
              nb::ndarray<nb::device::cuda> k_out, float epsilon,
              uintptr_t stream_ptr, bool split_half = false,
              int64_t rot_dim = 0) {

  if (q.ndim() != 4 || k.ndim() != 4 || q_out.ndim() != 4 ||
      k_out.ndim() != 4) {
    throw std::runtime_error(
        "rms_rope Q/K inputs and outputs must be 4D BHND or BNHD tensors");
  }
  for (int axis = 0; axis < 4; ++axis) {
    if (k.shape(axis) != q.shape(axis) || q_out.shape(axis) != q.shape(axis) ||
        k_out.shape(axis) != q.shape(axis)) {
      throw std::runtime_error(
          "rms_rope Q/K input and output shapes must match");
    }
  }

  const int64_t batch = q.shape(0);
  const int64_t dim1 = q.shape(1);
  const int64_t dim2 = q.shape(2);
  const int64_t head_dim = q.shape(3);
  if (head_dim < 32 || head_dim % 32 != 0) {
    throw std::runtime_error(
        "native rms_rope requires head_dim to be a positive multiple of 32");
  }
  // rot_dim restricts the rotation to a head-dim prefix (partial rotary); the
  // norm always spans the full head_dim. 0 means rotate everything.
  const int64_t rot = rot_dim > 0 ? rot_dim : head_dim;
  if (rot % 2 != 0 || rot > head_dim) {
    throw std::runtime_error(
        "rms_rope rot_dim must be an even value <= head_dim");
  }
  if (freqs.ndim() != 6 || (freqs.shape(0) != 1 && freqs.shape(0) != batch) ||
      (freqs.shape(1) != 1 && freqs.shape(1) != dim1) ||
      (freqs.shape(2) != 1 && freqs.shape(2) != dim2) ||
      freqs.shape(3) != rot / 2 || freqs.shape(4) != 2 ||
      freqs.shape(5) != 2) {
    throw std::runtime_error(
        "rms_rope freqs shape must broadcast to Q/K");
  }
  if (q_scale.ndim() != 1 || k_scale.ndim() != 1 ||
      q_scale.shape(0) != head_dim || k_scale.shape(0) != head_dim) {
    throw std::runtime_error(
        "rms_rope scales must be 1D tensors of length head_dim");
  }

  const int input_dtype_code = map_dtype_to_code(q.dtype());
  const int k_dtype_code = map_dtype_to_code(k.dtype());
  const int q_out_dtype_code = map_dtype_to_code(q_out.dtype());
  const int k_out_dtype_code = map_dtype_to_code(k_out.dtype());
  const int freqs_dtype_code = map_dtype_to_code(freqs.dtype());
  const int scale_dtype_code = map_dtype_to_code(q_scale.dtype());
  const int k_scale_dtype_code = map_dtype_to_code(k_scale.dtype());
  if ((input_dtype_code != 1 && input_dtype_code != 2) ||
      input_dtype_code != k_dtype_code ||
      input_dtype_code != q_out_dtype_code ||
      input_dtype_code != k_out_dtype_code) {
    throw std::runtime_error(
        "rms_rope Q/K inputs and outputs must share an FP16/BF16 dtype");
  }
  if (freqs_dtype_code < 0 || scale_dtype_code < 0 ||
      scale_dtype_code != k_scale_dtype_code) {
    throw std::runtime_error("rms_rope frequencies/scales must be FP32, FP16, "
                             "or BF16; scale dtypes must match");
  }

  launch_rms_rope_kernel(
      q.data(), k.data(), freqs.data(), q_scale.data(), k_scale.data(),
      q_out.data(), k_out.data(), batch, dim1, dim2, head_dim, rot,
      freqs.shape(0), freqs.shape(1), freqs.shape(2),
      q.stride(0), q.stride(1), q.stride(2), q.stride(3),
      k.stride(0), k.stride(1), k.stride(2), k.stride(3),
      q_out.stride(0), q_out.stride(1), q_out.stride(2), q_out.stride(3),
      k_out.stride(0), k_out.stride(1), k_out.stride(2), k_out.stride(3),
      freqs.stride(0), freqs.stride(1), freqs.stride(2), freqs.stride(3),
      freqs.stride(4), freqs.stride(5), q_scale.stride(0),
      k_scale.stride(0), epsilon, input_dtype_code,
      freqs_dtype_code, scale_dtype_code, true, split_half,
      reinterpret_cast<cudaStream_t>(stream_ptr));
}

// Nanobind wrapper for single-tensor fused RMSNorm + RoPE.
void rms_rope1(nb::ndarray<nb::device::cuda> q,
               nb::ndarray<nb::device::cuda> freqs,
               nb::ndarray<nb::device::cuda> q_scale,
               nb::ndarray<nb::device::cuda> q_out, float epsilon,
               uintptr_t stream_ptr, bool split_half = false) {

  if (q.ndim() != 4 || q_out.ndim() != 4) {
    throw std::runtime_error(
        "rms_rope1 input and output must be 4D BHND or BNHD tensors");
  }
  for (int axis = 0; axis < 4; ++axis) {
    if (q_out.shape(axis) != q.shape(axis)) {
      throw std::runtime_error("rms_rope1 output shape must match input shape");
    }
  }

  const int64_t batch = q.shape(0);
  const int64_t dim1 = q.shape(1);
  const int64_t dim2 = q.shape(2);
  const int64_t head_dim = q.shape(3);
  if (head_dim < 32 || head_dim % 32 != 0) {
    throw std::runtime_error(
        "native rms_rope1 requires head_dim to be a positive multiple of 32");
  }
  if (freqs.ndim() != 6 || (freqs.shape(0) != 1 && freqs.shape(0) != batch) ||
      (freqs.shape(1) != 1 && freqs.shape(1) != dim1) ||
      (freqs.shape(2) != 1 && freqs.shape(2) != dim2) ||
      freqs.shape(3) != head_dim / 2 || freqs.shape(4) != 2 ||
      freqs.shape(5) != 2) {
    throw std::runtime_error(
        "rms_rope1 freqs shape must broadcast to input");
  }
  if (q_scale.ndim() != 1 || q_scale.shape(0) != head_dim) {
    throw std::runtime_error(
        "rms_rope1 scale must be a 1D tensor of length head_dim");
  }

  const int input_dtype_code = map_dtype_to_code(q.dtype());
  const int out_dtype_code = map_dtype_to_code(q_out.dtype());
  const int freqs_dtype_code = map_dtype_to_code(freqs.dtype());
  const int scale_dtype_code = map_dtype_to_code(q_scale.dtype());
  if ((input_dtype_code != 1 && input_dtype_code != 2) ||
      input_dtype_code != out_dtype_code) {
    throw std::runtime_error(
        "rms_rope1 input/output must share an FP16/BF16 dtype");
  }
  if (freqs_dtype_code < 0 || scale_dtype_code < 0) {
    throw std::runtime_error(
        "rms_rope1 frequencies and scale must be FP32, FP16, or BF16");
  }

  launch_rms_rope_kernel(
      q.data(), nullptr, freqs.data(), q_scale.data(), nullptr, q_out.data(),
      nullptr, batch, dim1, dim2, head_dim, head_dim,
      freqs.shape(0), freqs.shape(1), freqs.shape(2),
      q.stride(0), q.stride(1), q.stride(2), q.stride(3),
      0, 0, 0, 0,
      q_out.stride(0), q_out.stride(1), q_out.stride(2), q_out.stride(3),
      0, 0, 0, 0,
      freqs.stride(0), freqs.stride(1), freqs.stride(2), freqs.stride(3),
      freqs.stride(4), freqs.stride(5), q_scale.stride(0), 0,
      epsilon, input_dtype_code,
      freqs_dtype_code, scale_dtype_code, false, split_half,
      reinterpret_cast<cudaStream_t>(stream_ptr));
}

// Nanobind wrapper: signed INT8 V quantization
void quant_v_int8(
    nb::ndarray<nb::device::cuda> v,
    nb::ndarray<nb::device::cuda> out,
    nb::ndarray<nb::device::cuda> scale,
    int padded_n,
    int input_dtype_code,
    uintptr_t stream_ptr)
{
    if (v.ndim() != 4) {
        throw std::runtime_error("quant_v_int8: v must be 4D [B,H,N,D]");
    }
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quant_v_int8_kernel(
        v.data(), out.data(), scale.data(),
        static_cast<int>(v.shape(0)),
        static_cast<int>(v.shape(1)),
        static_cast<int>(v.shape(2)),
        static_cast<int>(v.shape(3)),
        padded_n,
        v.stride(0), v.stride(1), v.stride(2),
        input_dtype_code, stream);
}

// Nanobind wrapper: stabilized INT8 Q/K per-thread quant (contiguous HND layout)
void quant_qk_per_thread_int8(
    nb::ndarray<nb::device::cuda> q,
    nb::ndarray<nb::device::cuda> q_int8,
    nb::ndarray<nb::device::cuda> q_scale,
    nb::ndarray<nb::device::cuda> k,
    nb::ndarray<nb::device::cuda> k_int8,
    nb::ndarray<nb::device::cuda> k_scale,
    int BLKQ, int WARPQ, int BLKK, int WARPK,
    int input_dtype_code,
    uintptr_t stream_ptr,
    uintptr_t anchor_indices_ptr)
{
    if (q.ndim() != 4 || k.ndim() != 4) {
        throw std::runtime_error("quant_qk_per_thread_int8: q and k must be 4D [B,H,L,D]");
    }
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quant_qk_per_thread_int8(
        q.data(), q_int8.data(), q_scale.data(),
        k.data(), k_int8.data(), k_scale.data(),
        static_cast<int>(q.shape(0)),
        static_cast<int>(q.shape(1)),
        static_cast<int>(q.shape(2)),
        static_cast<int>(k.shape(1)),
        static_cast<int>(k.shape(2)),
        static_cast<int>(q.shape(3)),
        BLKQ, WARPQ, BLKK, WARPK,
        q.stride(0), q.stride(1), q.stride(2),
        k.stride(0), k.stride(1), k.stride(2),
        input_dtype_code,
        reinterpret_cast<void *>(anchor_indices_ptr), stream);
}

// Quantization half of the split INT8 SDPA API.  This deliberately launches
// the same Q/K and V kernels with the same tiling as sage_sdpa below, so moving
// the attention launch after the caller releases its input tensors does not
// change any numerical results.
void sage_sdpa_quantize(
    nb::ndarray<nb::device::cuda> q,
    nb::ndarray<nb::device::cuda> k,
    nb::ndarray<nb::device::cuda> v,
    nb::ndarray<nb::device::cuda> q_int8,
    nb::ndarray<nb::device::cuda> q_scale,
    nb::ndarray<nb::device::cuda> k_int8,
    nb::ndarray<nb::device::cuda> k_scale,
    nb::ndarray<nb::device::cuda> v_int8,
    nb::ndarray<nb::device::cuda> v_scale,
    int cta_k,
    int input_dtype_code,
    uintptr_t stream_ptr,
    uintptr_t anchor_indices_ptr)
{
    if (q.ndim() != 4 || k.ndim() != 4 || v.ndim() != 4) {
        throw std::runtime_error(
            "sage_sdpa_quantize: q, k, and v must be 4D [B,H,L,D]");
    }
    if (cta_k != 64 && cta_k != 128) {
        throw std::runtime_error("sage_sdpa_quantize: cta_k must be 64 or 128");
    }
    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error(
            "sage_sdpa_quantize: input_dtype_code must be 0 (fp32), 1 (fp16), or 2 (bf16)");
    }
    if (!anchor_indices_ptr) {
        throw std::runtime_error(
            "sage_sdpa_quantize: anchor_indices scratch is required");
    }

    const int B = static_cast<int>(q.shape(0));
    const int H_q = static_cast<int>(q.shape(1));
    const int Lq = static_cast<int>(q.shape(2));
    const int D = static_cast<int>(q.shape(3));
    const int H_kv = static_cast<int>(k.shape(1));
    const int Lk = static_cast<int>(k.shape(2));
    const int padded_Lk = ((Lk + cta_k - 1) / cta_k) * cta_k;

    if (cta_k == 128 && D == 64) {
        throw std::runtime_error(
            "sage_sdpa_quantize: cta_k 128 is unsupported for head_dim 64");
    }

    if (k.shape(0) != B || v.shape(0) != B || v.shape(1) != H_kv ||
        v.shape(2) != Lk || k.shape(3) != D || v.shape(3) != D) {
        throw std::runtime_error("sage_sdpa_quantize: incompatible q, k, and v shapes");
    }
    if (q_int8.ndim() != 4 || k_int8.ndim() != 4 || v_int8.ndim() != 2 ||
        q_int8.shape(0) != B || q_int8.shape(1) != H_q ||
        q_int8.shape(2) != Lq || q_int8.shape(3) != D ||
        k_int8.shape(0) != B || k_int8.shape(1) != H_kv ||
        k_int8.shape(2) != Lk || k_int8.shape(3) != D ||
        v_int8.shape(0) != static_cast<size_t>(B) * H_kv * D ||
        v_int8.shape(1) != padded_Lk) {
        throw std::runtime_error("sage_sdpa_quantize: incompatible INT8 output shapes");
    }

    constexpr int BLKQ = 128;
    const int WARPQ = D == 256 ? 16 : 32;
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);

    launch_quant_qk_per_thread_int8(
        q.data(), q_int8.data(), q_scale.data(),
        k.data(), k_int8.data(), k_scale.data(),
        B, H_q, Lq, H_kv, Lk, D,
        BLKQ, WARPQ, cta_k, cta_k,
        q.stride(0), q.stride(1), q.stride(2),
        k.stride(0), k.stride(1), k.stride(2),
        input_dtype_code,
        reinterpret_cast<void *>(anchor_indices_ptr), stream);

    launch_quant_v_int8_kernel(
        v.data(), v_int8.data(), v_scale.data(),
        B, H_kv, Lk, D, padded_Lk,
        v.stride(0), v.stride(1), v.stride(2),
        input_dtype_code, stream);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        throw std::runtime_error(
            std::string("sage_sdpa_quantize kernel launch failed: ") +
            cudaGetErrorString(err));
    }
}

// Internal packed key masks are contiguous [mask_batch, mask_heads, width].
// Singleton batch/head dimensions are broadcast by the attention launcher.
void validate_prepared_key_mask(
    const nb::ndarray<nb::device::cuda> &packed, int B, int H, int Lk)
{
    const int width = ((((Lk + 127) / 128) * 129 + 3) / 4) * 4;
    if (packed.ndim() != 3 ||
        (packed.shape(0) != 1 && packed.shape(0) != B) ||
        (packed.shape(1) != 1 && packed.shape(1) != H) || packed.shape(2) != width ||
        packed.dtype() != nb::dtype<float>() || packed.stride(2) != 1 ||
        reinterpret_cast<uintptr_t>(packed.data()) % 8 != 0 ||
        (packed.shape(1) > 1 && packed.stride(1) != width) ||
        (packed.shape(0) > 1 && packed.stride(0) != packed.shape(1) * width)) {
        throw std::runtime_error("sage_sdpa: incompatible prepared key mask");
    }
}

void sage_prepare_key_mask(
    nb::ndarray<nb::device::cuda> mask,
    nb::ndarray<nb::device::cuda> packed, uintptr_t stream_ptr)
{
    if (mask.ndim() != 4 || mask.shape(2) != 1 || mask.shape(3) == 0 ||
        mask.device_id() != packed.device_id()) {
        throw std::runtime_error("sage_prepare_key_mask: expected [B,H,1,K] on the output device");
    }
    validate_prepared_key_mask(packed, mask.shape(0), mask.shape(1), mask.shape(3));
    if (packed.shape(0) != mask.shape(0) || packed.shape(1) != mask.shape(1)) {
        throw std::runtime_error("sage_prepare_key_mask: output batch/head dimensions must match");
    }
    const int dtype_code = mask.dtype().code == (uint8_t)nb::dlpack::dtype_code::Bool
        ? 3 : map_dtype_to_code(mask.dtype());
    launch_sage_prepare_key_mask(
        mask.data(), static_cast<float *>(packed.data()),
        mask.shape(0), mask.shape(1), mask.shape(3),
        mask.stride(0), mask.stride(1), mask.stride(3), dtype_code,
        reinterpret_cast<cudaStream_t>(stream_ptr));
}

struct SageAttentionMask {
    const void *data = nullptr;
    int64_t stride_b = 0;
    int64_t stride_h = 0;
    int64_t stride_q = 0;
    int64_t stride_k = 0;
    int dtype_code = -1;
    const float *tile_bias = nullptr;
};

SageAttentionMask parse_sage_attention_mask(
    const std::optional<nb::ndarray<nb::device::cuda>> &attn_mask,
    int B, int H, int Lq, int Lk, int D, int cta_k, int device_id)
{
    if (cta_k != 64 && cta_k != 128) {
        throw std::runtime_error("sage_sdpa: cta_k must be 64 or 128");
    }
    if (cta_k == 128 && (D == 64 || (attn_mask.has_value() && attn_mask->ndim() != 3))) {
        throw std::runtime_error(
            "sage_sdpa: cta_k 128 requires unmasked head_dim 128/256 or a prepared key mask");
    }
    SageAttentionMask result;
    if (!attn_mask.has_value()) {
        return result;
    }
    const auto &mask = attn_mask.value();
    if (mask.device_id() != device_id) {
        throw std::runtime_error("sage_sdpa: attention mask must be on the input device");
    }
    // The frontend expands ordinary masks to 4D; only prepared buffers are 3D.
    if (mask.ndim() == 3) {
        if ((D != 64 && D != 128 && D != 256) || cta_k != (D == 64 ? 64 : 128)) {
            throw std::runtime_error("sage_sdpa: incompatible head dimension or tile size for prepared mask");
        }
        validate_prepared_key_mask(mask, B, H, Lk);
        result.data = mask.data();
        result.stride_b = mask.shape(0) == 1 ? 0 : mask.stride(0);
        result.stride_h = mask.shape(1) == 1 ? 0 : mask.stride(1);
        result.stride_k = 1;
        result.dtype_code = 0;
        result.tile_bias = static_cast<const float *>(mask.data()) + ((Lk + 127) / 128) * 128;
    } else {
        if (mask.ndim() != 4 || mask.shape(0) != B || mask.shape(1) != H ||
            mask.shape(2) != Lq || mask.shape(3) != Lk) {
            throw std::runtime_error(
                "sage_sdpa: attention mask must be expanded to [B,H_q,Lq,Lk]");
        }
        result.dtype_code = mask.dtype().code == (uint8_t)nb::dlpack::dtype_code::Bool
            ? 3 : map_dtype_to_code(mask.dtype());
        if (result.dtype_code < 0 || result.dtype_code > 3) {
            throw std::runtime_error(
                "sage_sdpa: attention mask must be bool, float16, bfloat16, or float32");
        }
        result.data = mask.data();
        result.stride_b = mask.stride(0);
        result.stride_h = mask.stride(1);
        result.stride_q = mask.stride(2);
        result.stride_k = mask.stride(3);
    }
    return result;
}

// Attention half of the split INT8 SDPA API.  The input tensors use the exact
// packed layouts produced by sage_sdpa_quantize; no floating-point Q/K/V
// tensor is retained or reconstructed.
void sage_sdpa_prequantized(
    nb::ndarray<nb::device::cuda> q_int8,
    nb::ndarray<nb::device::cuda> k_int8,
    nb::ndarray<nb::device::cuda> v_int8,
    nb::ndarray<nb::device::cuda> o,
    nb::ndarray<nb::device::cuda> q_scale,
    nb::ndarray<nb::device::cuda> k_scale,
    nb::ndarray<nb::device::cuda> v_scale,
    int cta_k,
    float sm_scale,
    int output_dtype_code,
    uintptr_t stream_ptr,
    std::optional<nb::ndarray<nb::device::cuda>> attn_mask)
{
    if (q_int8.ndim() != 4 || k_int8.ndim() != 4 ||
        v_int8.ndim() != 2 || o.ndim() != 4) {
        throw std::runtime_error(
            "sage_sdpa_prequantized: q/k/o must be 4D and packed v must be 2D");
    }
    if (output_dtype_code != 1 && output_dtype_code != 2) {
        throw std::runtime_error(
            "sage_sdpa_prequantized: output_dtype_code must be 1 (fp16) or 2 (bf16)");
    }

    const int B = static_cast<int>(q_int8.shape(0));
    const int H_q = static_cast<int>(q_int8.shape(1));
    const int Lq = static_cast<int>(q_int8.shape(2));
    const int D = static_cast<int>(q_int8.shape(3));
    const int H_kv = static_cast<int>(k_int8.shape(1));
    const int Lk = static_cast<int>(k_int8.shape(2));
    const auto mask = parse_sage_attention_mask(
        attn_mask, B, H_q, Lq, Lk, D, cta_k, q_int8.device_id());
    const int padded_Lk = ((Lk + cta_k - 1) / cta_k) * cta_k;

    if (k_int8.shape(0) != B || k_int8.shape(3) != D ||
        o.shape(0) != B || o.shape(1) != H_q || o.shape(2) != Lq ||
        o.shape(3) != D ||
        v_int8.shape(0) != static_cast<size_t>(B) * H_kv * D ||
        v_int8.shape(1) != padded_Lk) {
        throw std::runtime_error(
            "sage_sdpa_prequantized: incompatible quantized tensor shapes");
    }
    if (q_int8.stride(3) != 1 || q_int8.stride(2) != D ||
        q_int8.stride(1) != static_cast<int64_t>(Lq) * D ||
        k_int8.stride(3) != 1 || k_int8.stride(2) != D ||
        k_int8.stride(1) != static_cast<int64_t>(Lk) * D ||
        v_int8.stride(1) != 1 || v_int8.stride(0) != padded_Lk ||
        o.stride(3) != 1 || o.stride(2) != D ||
        o.stride(1) != static_cast<int64_t>(Lq) * D) {
        throw std::runtime_error(
            "sage_sdpa_prequantized: quantized tensors and output must be contiguous");
    }

    const int64_t qi_st_h = static_cast<int64_t>(Lq) * D;
    const int qi_st_n = D;
    const int64_t qi_st_bz = H_q * qi_st_h;
    const int64_t ki_st_h = static_cast<int64_t>(Lk) * D;
    const int ki_st_n = D;
    const int64_t ki_st_bz = H_kv * ki_st_h;
    const int v_st_d = padded_Lk;
    const int64_t v_st_h = static_cast<int64_t>(D) * padded_Lk;
    const int64_t v_st_bz = H_kv * v_st_h;
    const int64_t o_st_h = qi_st_h;
    const int o_st_n = D;
    const int64_t o_st_bz = qi_st_bz;

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);

    launch_sage_attn_kernel(
        q_int8.data(), k_int8.data(), v_int8.data(), o.data(),
        q_scale.data(), k_scale.data(), v_scale.data(),
        mask.data, mask.stride_b, mask.stride_h, mask.stride_q, mask.stride_k,
        mask.dtype_code, cta_k,
        B, Lq, Lk, H_q, H_kv, D,
        qi_st_bz, qi_st_n, qi_st_h,
        ki_st_bz, ki_st_n, ki_st_h,
        v_st_bz, v_st_h, v_st_d,
        o_st_bz, o_st_n, o_st_h,
        sm_scale, output_dtype_code, stream, mask.tile_bias);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        throw std::runtime_error(
            std::string("sage_sdpa_prequantized kernel launch failed: ") +
            cudaGetErrorString(err));
    }
}

// Nanobind wrapper: pure INT8 QK / U8-softmax / INT8-V attention kernel
void sage_attn(
    nb::ndarray<nb::device::cuda> q,
    nb::ndarray<nb::device::cuda> k,
    nb::ndarray<nb::device::cuda> v,
    nb::ndarray<nb::device::cuda> o,
    nb::ndarray<nb::device::cuda> q_scale,
    nb::ndarray<nb::device::cuda> k_scale,
    nb::ndarray<nb::device::cuda> v_scale,
    float sm_scale,
    int output_dtype_code,
    uintptr_t stream_ptr)
{
    if (q.ndim() != 4 || k.ndim() != 4 || v.ndim() != 4 || o.ndim() != 4) {
        throw std::runtime_error("sage_attn: q, k, v, o must be 4D");
    }

    if (output_dtype_code != 1 && output_dtype_code != 2) {
        throw std::runtime_error("sage_attn: output_dtype_code must be 1 (fp16) or 2 (bf16)");
    }

    constexpr int CTA_K = 64;
    const int64_t padded_k_length =
        ((static_cast<int64_t>(k.shape(2)) + CTA_K - 1) / CTA_K) * CTA_K;
    if (v.shape(3) < padded_k_length || v.shape(3) % CTA_K != 0) {
        throw std::runtime_error(
            "sage_attn: packed V sequence extent must cover K and be a multiple of 64");
    }

    // Sequence strides still feed the 32-bit within-head tile iterators.
    if (q.stride(2) > INT_MAX || k.stride(2) > INT_MAX ||
        v.stride(2) > INT_MAX || o.stride(2) > INT_MAX) {
        throw std::overflow_error(
            "sage_attn: within-head strides exceed int32 range");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_sage_attn_kernel(
        q.data(), k.data(), v.data(), o.data(),
        q_scale.data(), k_scale.data(), v_scale.data(),
        nullptr, 0, 0, 0, 0, -1,
        CTA_K,
        static_cast<int>(q.shape(0)),
        static_cast<int>(q.shape(2)),
        static_cast<int>(k.shape(2)),
        static_cast<int>(q.shape(1)),
        static_cast<int>(k.shape(1)),
        static_cast<int>(q.shape(3)),
        q.stride(0), q.stride(2), q.stride(1),
        k.stride(0), k.stride(2), k.stride(1),
        v.stride(0), v.stride(1), v.stride(2),
        o.stride(0), o.stride(2), o.stride(1),
        sm_scale, output_dtype_code, stream);
}

// Fused SageAttention SDPA: quant_qk + quant_v + sage_attn in one C++ call.
// All scratch buffers are pre-allocated by the caller (Python frontend).
void sage_sdpa(
    nb::ndarray<nb::device::cuda> q,
    nb::ndarray<nb::device::cuda> k,
    nb::ndarray<nb::device::cuda> v,
    nb::ndarray<nb::device::cuda> o,
    nb::ndarray<nb::device::cuda> q_int8,
    nb::ndarray<nb::device::cuda> q_scale,
    nb::ndarray<nb::device::cuda> k_int8,
    nb::ndarray<nb::device::cuda> k_scale,
    nb::ndarray<nb::device::cuda> v_int8,
    nb::ndarray<nb::device::cuda> v_scale,
    float sm_scale,
    int input_dtype_code,
    int output_dtype_code,
    uintptr_t stream_ptr,
    uintptr_t anchor_indices_ptr,
    std::optional<nb::ndarray<nb::device::cuda>> attn_mask,
    int cta_k)
{
    if (q.ndim() != 4 || k.ndim() != 4 || v.ndim() != 4 || o.ndim() != 4) {
        throw std::runtime_error("sage_sdpa: q, k, v, o must be 4D [B,H,L,D]");
    }

    const int B = static_cast<int>(q.shape(0));
    const int H_q = static_cast<int>(q.shape(1));
    const int Lq = static_cast<int>(q.shape(2));
    const int D = static_cast<int>(q.shape(3));
    const int H_kv = static_cast<int>(k.shape(1));
    const int Lk = static_cast<int>(k.shape(2));

    const auto mask = parse_sage_attention_mask(
        attn_mask, B, H_q, Lq, Lk, D, cta_k, q.device_id());

    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error("sage_sdpa: input_dtype_code must be 0 (fp32), 1 (fp16), or 2 (bf16)");
    }
    if (output_dtype_code != 1 && output_dtype_code != 2) {
        throw std::runtime_error(
            "sage_sdpa: output_dtype_code must be 1 (fp16) or 2 (bf16)");
    }
    if (!anchor_indices_ptr) {
        throw std::runtime_error(
            "sage_sdpa: anchor_indices scratch is required");
    }
    constexpr int BLKQ = 128;
    const int WARPQ = D == 256 ? 16 : 32;
    const int BLKK = cta_k;
    const int WARPK = cta_k;
    const int padded_Lk = ((Lk + cta_k - 1) / cta_k) * cta_k;

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);

    launch_quant_qk_per_thread_int8(
        q.data(), q_int8.data(), q_scale.data(),
        k.data(), k_int8.data(), k_scale.data(),
        B, H_q, Lq, H_kv, Lk, D,
        BLKQ, WARPQ, BLKK, WARPK,
        q.stride(0), q.stride(1), q.stride(2),
        k.stride(0), k.stride(1), k.stride(2),
        input_dtype_code,
        reinterpret_cast<void *>(anchor_indices_ptr), stream);

    launch_quant_v_int8_kernel(
        v.data(), v_int8.data(), v_scale.data(),
        B, H_kv, Lk, D, padded_Lk,
        v.stride(0), v.stride(1), v.stride(2),
        input_dtype_code, stream);

    // Quantization packs each head contiguously, but a batch can exceed 2 GiB.
    // Keep batch/head addressing wide all the way through the attention launch.
    const int64_t qi_st_h = static_cast<int64_t>(Lq) * D;
    const int64_t qi_st_bz = H_q * qi_st_h;
    const int64_t ki_st_h = static_cast<int64_t>(Lk) * D;
    const int64_t ki_st_bz = H_kv * ki_st_h;
    const int64_t o_st_h = qi_st_h, o_st_bz = qi_st_bz;
    const int qi_st_n = D, ki_st_n = D, o_st_n = D;
    // v_int8 is [B*H_kv*D, padded_Lk] (2D from quant kernel).
    // Attention expects V as [B, H, D, padded_N].
    const int v_st_d  = padded_Lk;
    const int64_t v_st_h = static_cast<int64_t>(D) * padded_Lk;
    const int64_t v_st_bz = H_kv * v_st_h;

    launch_sage_attn_kernel(
        q_int8.data(), k_int8.data(), v_int8.data(), o.data(),
        q_scale.data(), k_scale.data(), v_scale.data(),
        mask.data, mask.stride_b, mask.stride_h, mask.stride_q, mask.stride_k,
        mask.dtype_code, cta_k,
        B, Lq, Lk, H_q, H_kv, D,
        qi_st_bz, qi_st_n, qi_st_h,
        ki_st_bz, ki_st_n, ki_st_h,
        v_st_bz, v_st_h, v_st_d,
        o_st_bz, o_st_n, o_st_h,
        sm_scale, output_dtype_code, stream, mask.tile_bias);

    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
        throw std::runtime_error(
            std::string("sage_sdpa kernel launch failed: ") + cudaGetErrorString(err));
    }
}

// ---------------------------------------------------------------------------
// SVDQuant W4A4 — nanobind/DLPack bindings for the native kitchen int4 kernels
// (see ops/quantize_svdquant_w4a4.cu and ops/scaled_mm_svdquant_w4a4.cu).
// ---------------------------------------------------------------------------

static int svdquant_dtype_code(const nb::dlpack::dtype& dt) {
    int c = map_dtype_to_code(dt);
    if (c < 0) throw std::runtime_error("svdquant: unsupported dtype");
    return c;
}

void svdquant_quantize_w4a4(
    nb::ndarray<nb::device::cuda> x,           // (M, K) bf16/fp16 — pre-shifted if unsigned path
    nb::ndarray<nb::device::cuda> smooth,      // (K,)
    nb::ndarray<nb::device::cuda> lora_down,   // (K, R)
    nb::ndarray<nb::device::cuda> q_x,         // (M_pad, K/2) int8
    nb::ndarray<nb::device::cuda> ascales,     // (K/G, M_pad)
    nb::ndarray<nb::device::cuda> lora_act,    // (M_pad, R) fp32
    bool act_unsigned,
    uintptr_t stream_ptr)
{
    int M = static_cast<int>(x.shape(0));
    int K = static_cast<int>(x.shape(1));
    int M_pad = static_cast<int>(q_x.shape(0));
    int R = static_cast<int>(lora_down.shape(1));
    int input_code = svdquant_dtype_code(x.dtype());

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_svdquant_quantize_w4a4_kernel(
        x.data(), smooth.data(), lora_down.data(),
        q_x.data(), ascales.data(), lora_act.data(),
        M, M_pad, K, R, input_code,
        static_cast<int>(act_unsigned), stream);
}

void svdquant_scaled_mm_w4a4(
    nb::ndarray<nb::device::cuda> act,           // (M, K/2) int8
    nb::ndarray<nb::device::cuda> wgt,           // (N, K/2) int8
    nb::ndarray<nb::device::cuda> ascales,       // (K/G, M)
    nb::ndarray<nb::device::cuda> wscales,       // (K/G, N)
    nb::ndarray<nb::device::cuda> lora_act_in,   // (M, R) fp32
    nb::ndarray<nb::device::cuda> lora_up,       // (N, R)
    nb::ndarray<nb::device::cuda> bias,          // (N,) or empty
    nb::ndarray<nb::device::cuda> out,           // (M, N)
    bool act_unsigned,
    bool fast_accum,
    bool shared_scale,
    bool fuse_lora,
    uintptr_t stream_ptr)
{
    int M = static_cast<int>(act.shape(0));
    int K = static_cast<int>(act.shape(1)) * 2;
    const bool tile_packed = (wgt.ndim() == 4);
    int N = tile_packed ? static_cast<int>(wgt.shape(0)) * 128 : static_cast<int>(wgt.shape(0));
    int R = static_cast<int>(lora_act_in.shape(1));
    int out_code = svdquant_dtype_code(out.dtype());
    if (fuse_lora && svdquant_dtype_code(lora_act_in.dtype()) != out_code) {
        throw std::runtime_error(
            "svdquant_scaled_mm_w4a4: fused LoRA-up requires lora_act_in dtype "
            "to match output/lora_up dtype");
    }

    if (tile_packed) {
        if (wgt.shape(1) != K / 64 || wgt.shape(2) != 32 || wgt.shape(3) != 128) {
            throw std::runtime_error(
                "svdquant_scaled_mm_w4a4: tile-packed weight must have shape "
                "(N/128, K/64, 32, 128)");
        }
        if (wscales.ndim() != 3 || wscales.shape(0) != wgt.shape(0) ||
            wscales.shape(1) != K / 64 || wscales.shape(2) != 128) {
            throw std::runtime_error(
                "svdquant_scaled_mm_w4a4: tile-packed wscales must have shape "
                "(N/128, K/64, 128)");
        }
    }

    const void* bias_ptr = (bias.data() != nullptr && bias.size() > 0) ? bias.data() : nullptr;
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_svdquant_scaled_mm_w4a4_kernel(
        act.data(), wgt.data(),
        ascales.data(), wscales.data(),
        lora_act_in.data(), lora_up.data(), bias_ptr,
        out.data(),
        M, N, K, R,
        static_cast<int>(act_unsigned), out_code,
        static_cast<int>(tile_packed), static_cast<int>(fast_accum),
        static_cast<int>(shared_scale), static_cast<int>(fuse_lora), stream);
}

// ---------------------------------------------------------------------------
// AWQ W4A16 — int4 weight, fp16/bf16 activation matmul. See ops/awq_w4a16.cu.
// ---------------------------------------------------------------------------
void awq_w4a16(
    nb::ndarray<nb::device::cuda> x,         // (M, K) bf16/fp16
    nb::ndarray<nb::device::cuda> qweight,   // (N, K/2) int8 packed uint4
    nb::ndarray<nb::device::cuda> wscales,   // (K/G, N)
    nb::ndarray<nb::device::cuda> wzeros,    // (K/G, N)
    nb::ndarray<nb::device::cuda> out,       // (M, N)
    int group_size,
    uintptr_t stream_ptr)
{
    const int M = static_cast<int>(x.shape(0));
    const int K = static_cast<int>(x.shape(1));
    const int N = static_cast<int>(qweight.shape(0));
    const int dtype_code = svdquant_dtype_code(x.dtype());
    if (dtype_code != 1 && dtype_code != 2) {
        throw std::runtime_error("awq_w4a16: only fp16 (1) and bf16 (2) activations supported");
    }
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_awq_w4a16_kernel(
        x.data(), qweight.data(), wscales.data(), wzeros.data(), out.data(),
        M, N, K, group_size, dtype_code, stream);
}

// Nanobind wrapper for fused 3D neighborhood attention
void na3d(
    nb::ndarray<nb::device::cuda> q,
    nb::ndarray<nb::device::cuda> k,
    nb::ndarray<nb::device::cuda> v,
    nb::ndarray<nb::device::cuda> out,
    int64_t batch, int64_t t_size, int64_t h_size, int64_t w_size,
    int64_t num_heads, int64_t head_dim,
    int64_t kt, int64_t kh, int64_t kw,
    int causal_t, int causal_h, int causal_w,
    float scale,
    int dtype_code,
    uintptr_t stream_ptr)
{
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_na3d_kernel(
        q.data(), k.data(), v.data(), out.data(),
        (int)batch, (int)t_size, (int)h_size, (int)w_size, (int)num_heads, (int)head_dim,
        (int)kt, (int)kh, (int)kw, causal_t, causal_h, causal_w,
        scale, dtype_code, stream);
}

// Nanobind wrappers for Sol-Attn sparse attention
static void check_block_len(const nb::ndarray<nb::device::cuda>& b, int64_t seq_len, const char* who) {
    if (b.dtype() != nb::dtype<int32_t>() || b.ndim() != 1 || b.stride(0) != 1 ||
        (int64_t)b.size() != (seq_len + 63) / 64)
        throw std::runtime_error(std::string(who) + ": block_len must be a contiguous 1-D int32 array of ceil(T/64) elements");
}

static void need_elems(const nb::ndarray<nb::device::cuda>& a, int64_t n, const char* who, const char* what) {
    if ((int64_t)a.size() != n)
        throw std::runtime_error(std::string(who) + ": " + what + " must have " + std::to_string(n)
                                 + " elements, got " + std::to_string(a.size()));
}
static void need_workspace(const nb::ndarray<nb::device::cuda>& ws, int64_t batch, int64_t seq_len,
                           int64_t num_heads, int64_t token_aug, const char* who) {
    int64_t v[48];
    const int n = sol_attn_plan((int)batch, (int)seq_len, (int)num_heads, (int)token_aug, v, 48);
    if (n > 48 || (int64_t)ws.size() < v[n - 1])   // last slot is "total"
        throw std::runtime_error(std::string(who) + ": workspace too small for this shape");
}
// q/k/v/out element code for launch_sol_attn: 0 = bfloat16, 1 = float16, -1 = neither
static int sol_elem_code(const nb::ndarray<nb::device::cuda>& a) {
    if (a.dtype().bits != 16) return -1;
    if (a.dtype().code == (uint8_t)nb::dlpack::dtype_code::Bfloat) return 0;
    if (a.dtype().code == (uint8_t)nb::dlpack::dtype_code::Float) return 1;
    return -1;
}
static void need_bthd(const nb::ndarray<nb::device::cuda>& a, int64_t b, int64_t t, int64_t h, int64_t d,
                      int elem, const char* who, const char* what) {
    if (a.ndim() != 4 || sol_elem_code(a) != elem ||
        a.shape(0) != (size_t)b || a.shape(1) != (size_t)t || a.shape(2) != (size_t)h || a.shape(3) != (size_t)d)
        throw std::runtime_error(std::string(who) + ": " + what
                                 + " must be a (B, T, H, D) array of q's dtype (bfloat16 or float16)");
}
// The kernels stage rows with 16-byte loads: unit last stride, 16 B base, and
// leading strides (of non-singleton dims) that keep every row 16 B aligned.
static void need_staging_layout(const nb::ndarray<nb::device::cuda>& a, const char* who, const char* what) {
    bool ok = a.stride(3) == 1 && reinterpret_cast<uintptr_t>(a.data()) % 16 == 0;
    for (int i = 0; i < 3; ++i) ok = ok && (a.shape(i) <= 1 || a.stride(i) % 8 == 0);
    if (!ok)
        throw std::runtime_error(std::string(who) + ": " + what
            + " must have a contiguous last dim, a 16-byte aligned base and leading strides that are multiples of 8");
}
template <typename A>
static void need_contiguous(const A& a, const char* who, const char* what) {
    int64_t expect = 1;
    for (int i = (int)a.ndim() - 1; i >= 0; --i) {
        if (a.shape(i) > 1 && a.stride(i) != expect)
            throw std::runtime_error(std::string(who) + ": " + what + " must be contiguous");
        expect *= (int64_t)a.shape(i);
    }
}

// Workspace dims and slot byte offsets, from the C++ Plan (the one definition).
nb::dict sol_attn_plan_py(int64_t batch, int64_t seq_len, int64_t num_heads, int64_t token_aug = 0) {
    int64_t v[48];
    const int n = sol_attn_plan((int)batch, (int)seq_len, (int)num_heads, (int)token_aug, v, 48);
    if (n > 48)
        throw std::runtime_error("sol_attn_plan: Plan grew past the binding's buffer");
    nb::dict d;
    for (int i = 0; i < n && sol_attn_plan_names[i]; ++i) d[sol_attn_plan_names[i]] = v[i];
    return d;
}

void sol_attn(
    nb::ndarray<nb::device::cuda> q,
    nb::ndarray<nb::device::cuda> k,
    nb::ndarray<nb::device::cuda> v,
    nb::ndarray<nb::device::cuda> out,
    nb::ndarray<nb::device::cuda> workspace,
    int64_t batch, int64_t seq_len, int64_t num_heads, int64_t head_dim,
    float tau, float scale,
    int64_t sink_start, int64_t sink_end, int64_t sink_q_start, int64_t sink_q_end,
    uintptr_t stream_ptr,
    std::optional<nb::ndarray<nb::device::cuda>> key_bias = std::nullopt,
    std::optional<nb::ndarray<nb::device::cuda>> threshold = std::nullopt,
    std::optional<nb::ndarray<nb::device::cuda>> block_len = std::nullopt,
    bool tail = true, int64_t token_aug = 0)
{
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    if (threshold && (int64_t)threshold->size() != batch * num_heads * ((seq_len + 63) / 64))
        throw std::runtime_error("sol_attn: threshold must have B*H*ceil(T/64) elements");
    if (block_len) check_block_len(*block_len, seq_len, "sol_attn");
    const int elem = sol_elem_code(q);
    if (elem < 0) throw std::runtime_error("sol_attn: q must be bfloat16 or float16");
    need_bthd(q, batch, seq_len, num_heads, head_dim, elem, "sol_attn", "q");
    need_bthd(k, batch, seq_len, num_heads, head_dim, elem, "sol_attn", "k");
    need_bthd(v, batch, seq_len, num_heads, head_dim, elem, "sol_attn", "v");
    need_bthd(out, batch, seq_len, num_heads, head_dim, elem, "sol_attn", "out");
    need_staging_layout(q, "sol_attn", "q");
    need_staging_layout(k, "sol_attn", "k");
    need_staging_layout(v, "sol_attn", "v");
    need_contiguous(out, "sol_attn", "out");
    need_workspace(workspace, batch, seq_len, num_heads, token_aug, "sol_attn");
    if (key_bias) need_elems(*key_bias, batch * seq_len, "sol_attn", "key_bias");
    // Explicit strides: only the last dim must be contiguous (BHND views go in as-is).
    launch_sol_attn(
        q.data(), k.data(), v.data(), out.data(), workspace.data(),
        (int)batch, (int)seq_len, (int)num_heads, (int)head_dim, elem,
        tau, scale,
        key_bias ? key_bias->data() : nullptr,
        threshold ? threshold->data() : nullptr,
        block_len ? block_len->data() : nullptr, tail ? 1 : 0,
        (int)sink_start, (int)sink_end, (int)sink_q_start, (int)sink_q_end,
        q.stride(0), q.stride(1), q.stride(2),
        k.stride(0), k.stride(1), k.stride(2),
        v.stride(0), v.stride(1), v.stride(2), (int)token_aug, stream);
}

void sol_producer_begin_py(nb::ndarray<nb::device::cuda> workspace,
                           int64_t batch, int64_t seq_len, int64_t num_heads,
                           uintptr_t stream_ptr, int64_t token_aug = 0) {
    sol_producer_begin(workspace.data(), (int)batch, (int)seq_len,
                       (int)num_heads, (int)token_aug, reinterpret_cast<cudaStream_t>(stream_ptr));
}

void sol_producer_chunk_py(
    nb::ndarray<nb::device::cuda> workspace, nb::ndarray<nb::device::cuda> qkv,
    nb::ndarray<nb::device::cuda> fab, nb::ndarray<nb::device::cuda> qw,
    nb::ndarray<nb::device::cuda> kw, nb::ndarray<nb::device::cuda> kmean,
    nb::ndarray<nb::device::cuda> vscale,
    float rope_eps, int64_t rot_dim, int64_t t0, int64_t m,
    int64_t batch, int64_t seq_len, int64_t num_heads,
    uintptr_t stream_ptr,
    std::optional<nb::ndarray<nb::device::cuda>> block_len = std::nullopt, int64_t token_aug = 0) {
    if (batch != 1)
        throw std::runtime_error("sol_producer_chunk: the producer path is B=1 only");
    if (rot_dim <= 0 || rot_dim > 128 || rot_dim % 8)
        throw std::runtime_error("sol_producer_chunk: rot_dim must be a multiple of 8 in (0, 128]");
    if (t0 < 0 || m < 0 || t0 + m > seq_len || (m && t0 % 64))
        throw std::runtime_error("sol_producer_chunk: chunk [t0, t0 + m) must lie in [0, seq_len] with a 64-aligned start");
    if (block_len) check_block_len(*block_len, seq_len, "sol_producer_chunk");
    need_workspace(workspace, batch, seq_len, num_heads, token_aug, "sol_producer_chunk");
    need_elems(qkv, m * 3 * num_heads * 128, "sol_producer_chunk", "qkv");
    need_elems(fab, seq_len * rot_dim * 2, "sol_producer_chunk", "fab");
    need_elems(qw, 128, "sol_producer_chunk", "qw");
    need_elems(kw, 128, "sol_producer_chunk", "kw");
    need_elems(kmean, batch * num_heads * 128, "sol_producer_chunk", "kmean");
    need_elems(vscale, batch * num_heads * 128, "sol_producer_chunk", "vscale");
    sol_producer_chunk(workspace.data(), qkv.data(), fab.data(), qw.data(),
                       kw.data(), kmean.data(), vscale.data(),
                       block_len ? block_len->data() : nullptr,
                       rope_eps, (int)rot_dim, (int)t0, (int)m,
                       (int)batch, (int)seq_len, (int)num_heads, (int)token_aug,
                       reinterpret_cast<cudaStream_t>(stream_ptr));
}

void sol_attn_core_py(
    nb::ndarray<nb::device::cuda> workspace, nb::ndarray<nb::device::cuda> out,
    nb::ndarray<nb::device::cuda> vscale, nb::ndarray<nb::device::cuda> kmean_next,
    nb::ndarray<nb::device::cuda> vamax_out,
    int64_t batch, int64_t seq_len, int64_t num_heads,
    float tau, float scale,
    int64_t sink_start, int64_t sink_end, int64_t sink_q_start, int64_t sink_q_end,
    uintptr_t stream_ptr,
    std::optional<nb::ndarray<nb::device::cuda>> threshold = std::nullopt,
    std::optional<nb::ndarray<nb::device::cuda>> block_len = std::nullopt,
    bool tail = true, int64_t token_aug = 0) {
    const int64_t stats = batch * num_heads * 128;
    if ((int64_t)vscale.size() != stats || (int64_t)kmean_next.size() != stats ||
        (int64_t)vamax_out.size() != stats)
        throw std::runtime_error("sol_attn_core: vscale/kmean_next/vamax_out must have B*H*128 elements");
    if (threshold && (int64_t)threshold->size() != batch * num_heads * ((seq_len + 63) / 64))
        throw std::runtime_error("sol_attn_core: threshold must have B*H*ceil(T/64) elements");
    if (block_len) check_block_len(*block_len, seq_len, "sol_attn_core");
    need_workspace(workspace, batch, seq_len, num_heads, token_aug, "sol_attn_core");
    need_elems(out, batch * seq_len * num_heads * 128, "sol_attn_core", "out");
    launch_sol_attn_core(
        workspace.data(), out.data(), vscale.data(), kmean_next.data(), vamax_out.data(),
        block_len ? block_len->data() : nullptr, tail ? 1 : 0,
        (int)batch, (int)seq_len, (int)num_heads,
        tau, scale, threshold ? threshold->data() : nullptr,
        (int)sink_start, (int)sink_end, (int)sink_q_start, (int)sink_q_end,
        (int)token_aug, reinterpret_cast<cudaStream_t>(stream_ptr));
}

// Nanobind wrapper for fused AdaLN (LayerNorm statistics)
void adaln(
    nb::ndarray<nb::device::cuda> x,
    nb::ndarray<nb::device::cuda> scale,
    nb::ndarray<nb::device::cuda> shift,
    nb::ndarray<nb::device::cuda> out,
    int64_t N,
    int64_t D,
    int64_t scale_group,
    int64_t shift_group,
    float   eps,
    int     dtype_code,
    uintptr_t stream_ptr)
{
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_adaln_kernel(
        x.data(), scale.data(), shift.data(), out.data(),
        N, D, scale_group, shift_group, eps, dtype_code, /*subtract_mean=*/true, stream);
}

// Nanobind wrapper for fused AdaLN with RMSNorm statistics
void rms_adaln(
    nb::ndarray<nb::device::cuda> x,
    nb::ndarray<nb::device::cuda> scale,
    nb::ndarray<nb::device::cuda> shift,
    nb::ndarray<nb::device::cuda> out,
    int64_t N,
    int64_t D,
    int64_t scale_group,
    int64_t shift_group,
    float   eps,
    int     dtype_code,
    uintptr_t stream_ptr)
{
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_adaln_kernel(
        x.data(), scale.data(), shift.data(), out.data(),
        N, D, scale_group, shift_group, eps, dtype_code, /*subtract_mean=*/false, stream);
}

// fp16-accumulate conv3d; all tensors fp16 NDHWC (validated in Python), residual is
// the full output or a K-vector of zeros. Returns false when the shape is declined.
bool cutlass_fp16_conv3d(
    nb::ndarray<nb::device::cuda> x,
    nb::ndarray<nb::device::cuda> w,
    nb::ndarray<nb::device::cuda> bias,
    nb::ndarray<nb::device::cuda> residual,
    nb::ndarray<nb::device::cuda> out,
    int64_t N, int64_t D, int64_t H, int64_t W, int64_t C,
    int64_t K, int64_t T, int64_t R, int64_t S,
    int64_t sd, int64_t sh, int64_t sw,
    uintptr_t stream_ptr, int64_t config = -1,
    int64_t xs_w = 0, int64_t xs_h = 0, int64_t xs_d = 0, int64_t xs_n = 0,
    int64_t os_w = 0, int64_t os_h = 0, int64_t os_d = 0, int64_t os_n = 0)
{
    // strides are element counts and index with int32 inside CUTLASS
    for (int64_t s : {xs_w, xs_h, xs_d, xs_n, os_w, os_h, os_d, os_n}) {
        if (s < 0 || s > INT32_MAX) throw std::invalid_argument("cutlass_fp16_conv3d: stride out of range");
    }
    if (sd <= 0 || sh <= 0 || sw <= 0) {
        throw std::invalid_argument("cutlass_fp16_conv3d: strides must be positive");
    }
    if (D < T || H < R || W < S) {
        throw std::invalid_argument("cutlass_fp16_conv3d: input smaller than the filter");
    }
    const int64_t Z = (D - T) / sd + 1, P = (H - R) / sh + 1, Q = (W - S) / sw + 1;
    const int64_t out_size = N * Z * P * Q * K;
    if (static_cast<int64_t>(x.size()) != N * D * H * W * C ||
        static_cast<int64_t>(w.size()) != K * T * R * S * C ||
        static_cast<int64_t>(bias.size()) != K ||
        static_cast<int64_t>(out.size()) != out_size ||
        (static_cast<int64_t>(residual.size()) != K && static_cast<int64_t>(residual.size()) != out_size)) {
        throw std::invalid_argument("cutlass_fp16_conv3d: tensor sizes do not match the given shape");
    }
    const bool resid_full = static_cast<int64_t>(residual.size()) == out_size;
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    return launch_cutlass_fp16_conv3d(
        x.data(), w.data(), bias.data(), residual.data(), resid_full, out.data(),
        static_cast<int>(N), static_cast<int>(D), static_cast<int>(H), static_cast<int>(W), static_cast<int>(C),
        static_cast<int>(K), static_cast<int>(T), static_cast<int>(R), static_cast<int>(S),
        static_cast<int>(Z), static_cast<int>(P), static_cast<int>(Q),
        static_cast<int>(sd), static_cast<int>(sh), static_cast<int>(sw), static_cast<int>(config),
        static_cast<int>(xs_w), static_cast<int>(xs_h), static_cast<int>(xs_d), static_cast<int>(xs_n),
        static_cast<int>(os_w), static_cast<int>(os_h), static_cast<int>(os_d), static_cast<int>(os_n),
        stream);
}

// Nanobind wrapper for the fused per-frame GroupNorm + SiLU + causal padding.
// weight/bias empty -> pad only; workspace empty is fine in that case.
void group_norm_silu_pad3d(
    nb::ndarray<nb::device::cuda> x,
    nb::ndarray<nb::device::cuda> weight,
    nb::ndarray<nb::device::cuda> bias,
    nb::ndarray<nb::device::cuda> out,
    nb::ndarray<nb::device::cuda> workspace,
    int64_t B, int64_t C, int64_t T, int64_t H, int64_t W,
    int64_t num_groups,
    float eps,
    int64_t left, int64_t right, int64_t top, int64_t bottom, int64_t front,
    bool silu,
    bool zero_pad,
    int dtype_code,
    uintptr_t stream_ptr)
{
    const bool norm = weight.size() > 0;
    if (norm && (static_cast<int64_t>(weight.size()) != C || static_cast<int64_t>(bias.size()) != C)) {
        throw std::invalid_argument("group_norm_silu_pad3d: weight and bias must have C elements");
    }
    if (static_cast<int64_t>(x.size()) != B * C * T * H * W ||
        static_cast<int64_t>(out.size()) != B * C * (T + front) * (H + top + bottom) * (W + left + right)) {
        throw std::invalid_argument("group_norm_silu_pad3d: x/out sizes do not match the given shape");
    }
    const int64_t chunks = (H * W + 1023) / 1024;
    if (norm && static_cast<int64_t>(workspace.size()) < 2 * B * T * (chunks * C + num_groups)) {
        throw std::invalid_argument("group_norm_silu_pad3d: workspace too small");
    }
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_group_norm_silu_pad3d(
        x.data(), norm ? weight.data() : nullptr, norm ? bias.data() : nullptr, out.data(),
        workspace.size() > 0 ? workspace.data() : nullptr,
        static_cast<int>(B), static_cast<int>(C), static_cast<int>(T), static_cast<int>(H), static_cast<int>(W),
        static_cast<int>(num_groups), eps,
        static_cast<int>(left), static_cast<int>(right), static_cast<int>(top), static_cast<int>(bottom),
        static_cast<int>(front), silu, zero_pad, dtype_code, stream);
}

// Python module definition
extern "C" {
    void launch_cublas_gemm_int8_kernel(
        const void* A_ptr,
        const void* B_ptr,
        void* C_ptr,
        int64_t M,
        int64_t N,
        int64_t K,
        void* workspace_ptr,
        int64_t workspace_size,
        cudaStream_t stream);

    void launch_quantize_int8_rowwise_kernel(
        const void* input,
        void* output,
        void* scales,
        int64_t num_rows,
        int64_t num_cols,
        int input_dtype_code,
        bool stochastic,
        uint64_t seed,
        cudaStream_t stream);

    void launch_quantize_int4_rowwise_kernel(
        const void* input,
        void* output,
        void* scales,
        int64_t M,
        int64_t K,
        int input_dtype_code,
        bool stochastic,
        uint64_t seed,
        cudaStream_t stream);

    void launch_quantize_int4_rowwise_convrot64_kernel(
        const void* input,
        void* output,
        void* scales,
        int64_t M,
        int64_t K,
        int group_size,
        int input_dtype_code,
        bool stochastic,
        uint64_t seed,
        cudaStream_t stream);

    void launch_quantize_int4_rowwise_convrot64_to_int8_kernel(
        const void* input,
        void* output,
        void* scales,
        int64_t M,
        int64_t K,
        int group_size,
        int input_dtype_code,
        bool stochastic,
        uint64_t seed,
        cudaStream_t stream);

    void launch_dequantize_int4_convrot64_kernel(
        const void* input,
        const void* scales,
        void* output,
        int64_t M,
        int64_t K,
        int64_t scale_size,
        int group_size,
        int output_dtype_code,
        cudaStream_t stream);

    void launch_int4_linear_kernel(
        const void* act,
        const void* weight,
        const void* x_scales,
        const void* weight_scales,
        const void* bias,
        void* output,
        int64_t M,
        int64_t N,
        int64_t K,
        bool has_bias,
        int output_dtype_code,
        int bias_dtype_code,
        cudaStream_t stream);

    void launch_unpack_int4_to_int8_kernel(
        const void* input,
        void* output,
        int64_t rows,
        int64_t K_half,
        cudaStream_t stream);

    void launch_int4_weight_int8_act_gemv_dequant_kernel(
        const void* input,
        const void* weight,
        const void* x_scales,
        const void* weight_scales,
        const void* bias,
        void* output,
        int64_t num_rows,
        int64_t num_cols,
        int64_t K,
        int64_t weight_scale_size,
        bool has_bias,
        int output_dtype_code,
        int bias_dtype_code,
        cudaStream_t stream);

    void launch_int4_weight_int8_act_gemm_dequant_chunked_kernel(
        const void* input,
        const void* weight,
        const void* x_scales,
        const void* weight_scales,
        const void* bias,
        void* output,
        void* weight_workspace,
        void* acc_workspace,
        void* cublas_workspace,
        int64_t cublas_workspace_size,
        int64_t num_rows,
        int64_t num_cols,
        int64_t K,
        int64_t weight_scale_size,
        int64_t chunk_cols,
        bool allow_sm80_cutlass,
        bool has_bias,
        int output_dtype_code,
        int bias_dtype_code,
        cudaStream_t stream);

    bool launch_cutlass_fp16_linear(
        const void* A,
        const void* B,
        const void* bias,
        void* D,
        int64_t M,
        int64_t N,
        int64_t K,
        cudaStream_t stream);

    bool launch_cutlass_fp16_linear_residual(
        const void* A,
        const void* B,
        const void* bias,
        const void* rscale,
        const void* resid,
        void* D,
        int64_t M,
        int64_t N,
        int64_t K,
        cudaStream_t stream);

    bool launch_cutlass_int8_dequant_residual(
        const void* A,
        const void* B,
        const void* xs,
        const void* ws,
        const void* bias,
        const void* rscale,
        const void* resid,
        void* D,
        int64_t M,
        int64_t N,
        int64_t K,
        int out_dtype_code,
        cudaStream_t stream);

    bool launch_cutlass_int8_dequant(
        const void* A,
        const void* B,
        const void* xs,
        const void* ws,
        const void* bias,
        void* D,
        int64_t M,
        int64_t N,
        int64_t K,
        int out_dtype_code,
        cudaStream_t stream);

    int cutlass_int8_selected_config(int64_t M, int64_t N, int64_t K);

    bool launch_cutlass_int8_dequant_config(
        const void* A,
        const void* B,
        const void* xs,
        const void* ws,
        void* D,
        int64_t M,
        int64_t N,
        int64_t K,
        int out_dtype_code,
        int config,
        cudaStream_t stream);

    bool launch_cutlass_turing_int8_dequant(
        const void* A,
        const void* B,
        const void* xs,
        const void* ws,
        const void* bias,
        void* D,
        int64_t M,
        int64_t N,
        int64_t K,
        int out_dtype_code,
        bool scalar_weight_scale,
        cudaStream_t stream);

    bool launch_cutlass_int4_dequant(
        const void* A,
        const void* B,
        const void* xs,
        const void* ws,
        const void* bias,
        void* D,
        int64_t M,
        int64_t N,
        int64_t K,
        int out_dtype_code,
        cudaStream_t stream);

    bool launch_cutlass_turing_int4_dequant(
        const void* A,
        const void* B,
        const void* xs,
        const void* ws,
        const void* bias,
        void* D,
        int64_t M,
        int64_t N,
        int64_t K,
        int out_dtype_code,
        cudaStream_t stream);

    void launch_dequant_int4_grouped_to_int8(
        const void* qw,
        const void* s_rel,
        const void* codebook,
        void* out,
        int64_t N,
        int64_t K,
        int64_t G,
        int64_t bits,
        cudaStream_t stream);

    void launch_dequant_int4_grouped_to_int8_e4m3(
        const void* qw,
        const void* s_rel,
        const void* codebook,
        void* out,
        int64_t N,
        int64_t K,
        int64_t G,
        int64_t bits,
        cudaStream_t stream);

    bool launch_quantize_w4a8_convrot(
        const void* rotated,
        const void* codebook,
        void* packed,
        void* s_rel,
        void* s_channel,
        int64_t N,
        int64_t K,
        int in_dtype_code,
        bool stochastic,
        uint64_t seed,
        cudaStream_t stream);

    bool launch_quantize_wxa8_convrot_fused(
        const void* weight,
        const void* codebook,
        void* packed,
        void* s_rel,
        void* s_channel,
        int64_t N,
        int64_t K,
        int bits,
        int G,
        int in_dtype_code,
        bool stochastic,
        uint64_t seed,
        cudaStream_t stream);

    bool launch_w4a8_codebook_gemm_chunked(
        const void* xq,
        const void* weight,
        const void* s_rel,
        const void* codebook,
        const void* s_channel,
        const void* xs,
        const void* bias,
        void* workspace,
        void* out,
        int64_t M,
        int64_t N,
        int64_t K,
        int64_t G,
        int64_t chunk_cols,
        int64_t bits,
        int out_dtype_code,
        cudaStream_t stream);

    bool launch_gated_delta_decode_fused(
        const void* mixed_qkv, const void* x, const void* w_a, const void* w_b,
        const void* dt_bias, const void* g_decay, void* state, void* out, void* snapshots,
        const void* z, const void* norm_w, float eps,
        int64_t B, int64_t Hv, int64_t Hk, int64_t S, int64_t DK, int64_t DV, int64_t C, int64_t Hd,
        int64_t key_dim, float scale, int dtype_code, cudaStream_t stream);

    bool launch_deltanet_conv_step(
        const void* proj, void* conv_state, const void* conv_w, const void* conv_b,
        void* conv_out, void* conv_snaps,
        int64_t B, int64_t C, int64_t S, int64_t KS, int dtype_code, cudaStream_t stream);

    bool launch_w4a8_codebook_gemv(
        const void* xq,
        const void* weight,
        const void* s_rel,
        const void* codebook,
        const void* s_channel,
        const void* xs,
        const void* bias,
        void* out,
        int64_t M,
        int64_t N,
        int64_t K,
        int64_t G,
        int64_t bits,
        int out_dtype_code,
        cudaStream_t stream);

    void launch_quantize_int8_rowwise_convrot_kernel(
        const void* input,
        void* output,
        void* scales,
        int64_t num_rows,
        int64_t num_cols,
        int group_size,
        int input_dtype_code,
        bool stochastic,
        uint64_t seed,
        cudaStream_t stream);

    void launch_rotate_int8_convrot_weight_kernel(
        const void* input,
        void* output,
        int64_t num_rows,
        int64_t num_cols,
        int group_size,
        int input_dtype_code,
        int output_dtype_code,
        cudaStream_t stream);

    void launch_quantize_int8_convrot_staged_kernel(
        const void* input,
        void* rotated,
        void* partial_absmax,
        void* output,
        void* scales,
        int64_t num_rows,
        int64_t num_cols,
        int group_size,
        int input_dtype_code,
        int rotated_dtype_code,
        bool stochastic,
        uint64_t seed,
        cudaStream_t stream);

    void launch_quantize_int8_rowwise_convrot64_kernel(
        const void* input,
        void* output,
        void* scales,
        int64_t num_rows,
        int64_t num_cols,
        int group_size,
        int input_dtype_code,
        bool stochastic,
        int act_code,
        uint64_t seed,
        const void* act_weight,
        float act_eps,
        cudaStream_t stream);

    void launch_dequantize_int8_linear_kernel(
        const void* input,
        const void* x_scales,
        const void* weight_scales,
        const void* bias,
        void* output,
        int64_t num_rows,
        int64_t num_cols,
        int64_t weight_scale_size,
        bool has_bias,
        int output_dtype_code,
        int bias_dtype_code,
        cudaStream_t stream);

    void launch_int8_gemv_dequant_kernel(
        const void* input,
        const void* weight,
        const void* x_scales,
        const void* weight_scales,
        const void* bias,
        void* output,
        int64_t num_rows,
        int64_t num_cols,
        int64_t K,
        int64_t weight_scale_size,
        bool has_bias,
        int output_dtype_code,
        int bias_dtype_code,
        cudaStream_t stream);

    void launch_dequantize_int8_simple_kernel(
        const void* input,
        const void* scales,
        void* output,
        int64_t total,
        int64_t inner_dim,
        int scale_mode,
        int output_dtype_code,
        cudaStream_t stream);

    void launch_dequantize_int8_convrot_kernel(
        const void* input,
        const void* scales,
        void* output,
        int64_t num_rows,
        int64_t num_cols,
        int64_t scale_size,
        int group_size,
        int output_dtype_code,
        cudaStream_t stream);

    void launch_flash_decode(
        const void* q, const void* k, const void* v, const int* kv_lengths,
        void* output, float* softmax_lse, float* softmax_lse_accum, float* output_accum,
        int batch, int query_length, int heads, int head_dim, int kv_capacity, int num_splits,
        int64_t q_batch_stride, int64_t q_row_stride, int64_t q_head_stride,
        int64_t k_batch_stride, int64_t k_row_stride, int64_t k_head_stride,
        cudaStream_t stream);

}

// Nanobind wrapper for cublas_gemm_int8
void cublas_gemm_int8(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> a,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> b,
    nb::ndarray<int32_t, nb::ndim<2>, nb::device::cuda> c,
    nb::ndarray<nb::device::cuda> workspace,
    uintptr_t stream_ptr) {

    auto& runtime = comfy::CublasLtRuntime::instance();
    if (!runtime.is_available()) {
        throw std::runtime_error("cuBLASLt not available: " + runtime.error_message());
    }

    // a is [M, K], b is [N, K], c is [M, N]
    int64_t M = a.shape(0);
    int64_t K = a.shape(1);
    int64_t N = b.shape(0);
    int64_t K_b = b.shape(1);

    if (K != K_b) {
        throw std::runtime_error("Matrix K dimensions do not match");
    }

    if (c.shape(0) != M || c.shape(1) != N) {
        throw std::runtime_error("Output matrix C shape does not match");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);

    launch_cublas_gemm_int8_kernel(
        a.data(),
        b.data(),
        c.data(),
        M, N, K,
        workspace.data(),
        workspace.size() > 0 ? (int64_t)workspace.size() : 0,
        stream);
}

void quantize_int8_rowwise(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> output,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> scales,
    bool stochastic,
    uint64_t seed,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);

    if (output.shape(0) != M || output.shape(1) != K) {
        throw std::runtime_error("INT8 rowwise quantization output shape mismatch");
    }
    if (scales.shape(0) != M || scales.shape(1) != 1) {
        throw std::runtime_error("INT8 rowwise quantization scale shape mismatch");
    }
    const int input_dtype_code = map_dtype_to_code(input.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error("Unsupported input dtype for INT8 rowwise quantization");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quantize_int8_rowwise_kernel(
        input.data(),
        output.data(),
        scales.data(),
        M,
        K,
        input_dtype_code,
        stochastic,
        seed,
        stream);
}

void quantize_int4_rowwise(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> output,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> scales,
    bool stochastic,
    uint64_t seed,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);
    if (K % 64 != 0) {
        throw std::runtime_error("INT4 rowwise quantization requires K divisible by 64");
    }
    if (output.shape(0) != M || output.shape(1) != K / 2) {
        throw std::runtime_error("INT4 rowwise quantization output shape mismatch");
    }
    if (scales.shape(0) != M || scales.shape(1) != 1) {
        throw std::runtime_error("INT4 rowwise quantization scale shape mismatch");
    }
    const int input_dtype_code = map_dtype_to_code(input.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error("Unsupported input dtype for INT4 rowwise quantization");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quantize_int4_rowwise_kernel(
        input.data(),
        output.data(),
        scales.data(),
        M,
        K,
        input_dtype_code,
        stochastic,
        seed,
        stream);
}

void quantize_int4_rowwise_convrot64(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> output,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> scales,
    int group_size,
    bool stochastic,
    uint64_t seed,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);
    if (group_size != 16 && group_size != 64 && group_size != 256) {
        throw std::runtime_error("INT4 ConvRot quantization requires group_size 16, 64, or 256");
    }
    if (K % group_size != 0) {
        throw std::runtime_error("INT4 ConvRot quantization requires K divisible by group_size");
    }
    if (output.shape(0) != M || output.shape(1) != K / 2) {
        throw std::runtime_error("INT4 ConvRot quantization output shape mismatch");
    }
    if (scales.shape(0) != M || scales.shape(1) != 1) {
        throw std::runtime_error("INT4 ConvRot quantization scale shape mismatch");
    }
    const int input_dtype_code = map_dtype_to_code(input.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error("Unsupported input dtype for INT4 ConvRot quantization");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quantize_int4_rowwise_convrot64_kernel(
        input.data(),
        output.data(),
        scales.data(),
        M,
        K,
        group_size,
        input_dtype_code,
        stochastic,
        seed,
        stream);
}

void quantize_int4_rowwise_convrot64_to_int8(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> output,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> scales,
    int group_size,
    bool stochastic,
    uint64_t seed,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);
    if (output.shape(0) != M || output.shape(1) != K) {
        throw std::runtime_error("INT4 ConvRot fallback activation output shape mismatch");
    }
    if (scales.shape(0) != M || scales.shape(1) != 1) {
        throw std::runtime_error("INT4 ConvRot fallback activation scales must have shape [M, 1]");
    }
    if (group_size != 256 || K % group_size != 0) {
        throw std::runtime_error("INT4 ConvRot fallback activation quantization requires group_size 256 and divisible K");
    }
    const int input_dtype_code = map_dtype_to_code(input.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error("Unsupported input dtype for INT4 ConvRot fallback activation quantization");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quantize_int4_rowwise_convrot64_to_int8_kernel(
        input.data(),
        output.data(),
        scales.data(),
        M,
        K,
        static_cast<int>(group_size),
        input_dtype_code,
        stochastic,
        seed,
        stream);
}

void dequantize_int4_convrot64(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<float, nb::ndim<1>, nb::device::cuda> scales,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> output,
    int group_size,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1) * 2;
    if (group_size != 16 && group_size != 64 && group_size != 256) {
        throw std::runtime_error("INT4 ConvRot dequantization requires group_size 16, 64, or 256");
    }
    if (K % group_size != 0) {
        throw std::runtime_error("INT4 ConvRot dequantization requires K divisible by group_size");
    }
    if (output.shape(0) != M || output.shape(1) != K) {
        throw std::runtime_error("INT4 ConvRot dequantization output shape mismatch");
    }
    if (scales.size() != 1 && scales.size() != static_cast<size_t>(M)) {
        throw std::runtime_error("INT4 ConvRot dequantization scale must be scalar or per-row");
    }
    const int output_dtype_code = map_dtype_to_code(output.dtype());
    if (output_dtype_code < 0 || output_dtype_code > 2) {
        throw std::runtime_error("Unsupported output dtype for INT4 ConvRot dequantization");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_dequantize_int4_convrot64_kernel(
        input.data(),
        scales.data(),
        output.data(),
        M,
        K,
        static_cast<int64_t>(scales.size()),
        group_size,
        output_dtype_code,
        stream);
}

void int4_linear(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> act,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> weight,
    nb::ndarray<float, nb::device::cuda> x_scales,
    nb::ndarray<float, nb::device::cuda> weight_scales,
    nb::ndarray<nb::device::cuda> bias,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> output,
    int output_dtype_code,
    uintptr_t stream_ptr) {

    const int64_t M = act.shape(0);
    const int64_t K_half = act.shape(1);
    const int64_t N = weight.shape(0);
    if (weight.shape(1) != K_half) {
        throw std::runtime_error("INT4 linear K dimensions do not match");
    }
    const int64_t K = K_half * 2;
    if (K % 64 != 0) {
        throw std::runtime_error("INT4 linear requires K divisible by 64");
    }
    if (x_scales.size() != static_cast<size_t>(M)) {
        throw std::runtime_error("INT4 linear x_scales must have one value per row");
    }
    if (weight_scales.size() != static_cast<size_t>(N)) {
        throw std::runtime_error("INT4 linear weight_scales must have one value per output channel");
    }
    if (output.shape(0) != M || output.shape(1) != N) {
        throw std::runtime_error("INT4 linear output shape mismatch");
    }
    const int out_dtype = map_dtype_to_code(output.dtype());
    if (out_dtype != output_dtype_code) {
        throw std::runtime_error("INT4 linear output dtype code mismatch");
    }
    if (output_dtype_code < 0 || output_dtype_code > 2) {
        throw std::runtime_error("Unsupported output dtype for INT4 linear");
    }

    const bool has_bias = bias.size() > 0;
    int bias_dtype_code = output_dtype_code;
    if (has_bias) {
        if (bias.size() != static_cast<size_t>(N)) {
            throw std::runtime_error("INT4 linear bias shape mismatch");
        }
        bias_dtype_code = map_dtype_to_code(bias.dtype());
        if (bias_dtype_code < 0 || bias_dtype_code > 2) {
            throw std::runtime_error("Unsupported bias dtype for INT4 linear");
        }
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_int4_linear_kernel(
        act.data(),
        weight.data(),
        x_scales.data(),
        weight_scales.data(),
        has_bias ? bias.data() : nullptr,
        output.data(),
        M,
        N,
        K,
        has_bias,
        output_dtype_code,
        bias_dtype_code,
        stream);
}

void unpack_int4_to_int8(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> output,
    uintptr_t stream_ptr) {

    const int64_t rows = input.shape(0);
    const int64_t K_half = input.shape(1);
    if (output.shape(0) != rows || output.shape(1) != K_half * 2) {
        throw std::runtime_error("unpack_int4_to_int8 output shape mismatch");
    }
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_unpack_int4_to_int8_kernel(input.data(), output.data(), rows, K_half, stream);
}

void int4_weight_int8_act_gemv_dequant(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> weight,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> x_scales,
    nb::ndarray<float, nb::device::cuda> weight_scales,
    nb::ndarray<nb::device::cuda> bias,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> output,
    int output_dtype_code,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);
    const int64_t N = weight.shape(0);
    if (weight.shape(1) * 2 != K) {
        throw std::runtime_error("packed INT4 weight GEMV weight K mismatch");
    }
    if (x_scales.shape(0) != M || x_scales.shape(1) != 1) {
        throw std::runtime_error("packed INT4 weight GEMV activation scale shape mismatch");
    }
    if (output.shape(0) != M || output.shape(1) != N) {
        throw std::runtime_error("packed INT4 weight GEMV output shape mismatch");
    }
    if (output_dtype_code < 0 || output_dtype_code > 2) {
        throw std::runtime_error("Invalid packed INT4 weight GEMV output dtype code");
    }

    const bool has_bias = bias.data() && bias.size() > 0;
    int bias_dtype_code = output_dtype_code;
    if (has_bias) {
        if (bias.shape(0) != N) {
            throw std::runtime_error("packed INT4 weight GEMV bias shape mismatch");
        }
        bias_dtype_code = map_dtype_to_code(bias.dtype());
        if (bias_dtype_code < 0 || bias_dtype_code > 2) {
            throw std::runtime_error("Unsupported bias dtype for packed INT4 weight GEMV");
        }
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_int4_weight_int8_act_gemv_dequant_kernel(
        input.data(),
        weight.data(),
        x_scales.data(),
        weight_scales.data(),
        has_bias ? bias.data() : nullptr,
        output.data(),
        M,
        N,
        K,
        static_cast<int64_t>(weight_scales.size()),
        has_bias,
        output_dtype_code,
        bias_dtype_code,
        stream);
}

void int4_weight_int8_act_gemm_dequant_chunked(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> weight,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> x_scales,
    nb::ndarray<float, nb::device::cuda> weight_scales,
    nb::ndarray<nb::device::cuda> bias,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> output,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> weight_workspace,
    nb::ndarray<int32_t, nb::ndim<2>, nb::device::cuda> acc_workspace,
    nb::ndarray<uint8_t, nb::device::cuda> cublas_workspace,
    int64_t chunk_cols,
    bool allow_sm80_cutlass,
    int output_dtype_code,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);
    const int64_t N = weight.shape(0);
    const int64_t K_half = weight.shape(1);
    if (K_half * 2 != K) {
        throw std::runtime_error("chunked INT4 weight GEMM weight K mismatch");
    }
    if (x_scales.shape(0) != M || x_scales.shape(1) != 1) {
        throw std::runtime_error("chunked INT4 weight GEMM activation scale shape mismatch");
    }
    if (output.shape(0) != M || output.shape(1) != N) {
        throw std::runtime_error("chunked INT4 weight GEMM output shape mismatch");
    }
    if (chunk_cols <= 0 || chunk_cols > N) {
        throw std::runtime_error("chunked INT4 weight GEMM invalid chunk_cols");
    }
    if (weight_workspace.shape(0) < chunk_cols || weight_workspace.shape(1) != K) {
        throw std::runtime_error("chunked INT4 weight GEMM weight workspace shape mismatch");
    }
    if (acc_workspace.shape(0) != M || acc_workspace.shape(1) < chunk_cols) {
        throw std::runtime_error("chunked INT4 weight GEMM accumulator workspace shape mismatch");
    }
    if (weight_scales.size() != 1 && static_cast<int64_t>(weight_scales.size()) != N) {
        throw std::runtime_error("chunked INT4 weight GEMM weight scale shape mismatch");
    }
    if (output_dtype_code < 0 || output_dtype_code > 2) {
        throw std::runtime_error("Invalid chunked INT4 weight GEMM output dtype code");
    }

    const bool has_bias = bias.data() && bias.size() > 0;
    int bias_dtype_code = output_dtype_code;
    if (has_bias) {
        if (bias.shape(0) != N) {
            throw std::runtime_error("chunked INT4 weight GEMM bias shape mismatch");
        }
        bias_dtype_code = map_dtype_to_code(bias.dtype());
        if (bias_dtype_code < 0 || bias_dtype_code > 2) {
            throw std::runtime_error("Unsupported bias dtype for chunked INT4 weight GEMM");
        }
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_int4_weight_int8_act_gemm_dequant_chunked_kernel(
        input.data(),
        weight.data(),
        x_scales.data(),
        weight_scales.data(),
        has_bias ? bias.data() : nullptr,
        output.data(),
        weight_workspace.data(),
        acc_workspace.data(),
        cublas_workspace.data(),
        static_cast<int64_t>(cublas_workspace.size()),
        M,
        N,
        K,
        static_cast<int64_t>(weight_scales.size()),
        chunk_cols,
        allow_sm80_cutlass,
        has_bias,
        output_dtype_code,
        bias_dtype_code,
        stream);
}

// Operand checks for the int8 fused-dequant GEMM bindings: A [M,K], B [N,K] int8,
// D [M,N] in out_dtype_code, xs [M] / ws [N] fp32, bias empty or [N] in the output dtype.
static std::tuple<int64_t, int64_t, int64_t> check_int8_gemm_operands(
    const char* name,
    const nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda>& a,
    const nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda>& b,
    const nb::ndarray<float, nb::device::cuda>& xs,
    const nb::ndarray<float, nb::device::cuda>& ws,
    const nb::ndarray<nb::device::cuda>& bias,
    const nb::ndarray<nb::ndim<2>, nb::device::cuda>& d,
    int out_dtype_code) {
    const int64_t M = a.shape(0);
    const int64_t K = a.shape(1);
    const int64_t N = b.shape(0);
    if (b.shape(1) != K) throw std::runtime_error(std::string(name) + ": K mismatch");
    if (d.shape(0) != M || d.shape(1) != N) throw std::runtime_error(std::string(name) + ": D shape mismatch");
    // size() tolerates the [M,1] scale the int8 caller passes; the output dtype must match
    // the code exactly (fp16 and bf16 share an itemsize but select different kernels).
    if (static_cast<int64_t>(xs.size()) != M) throw std::runtime_error(std::string(name) + ": xs must be a length-M vector");
    if (static_cast<int64_t>(ws.size()) != N) throw std::runtime_error(std::string(name) + ": ws must be a length-N vector");
    if (bias.size() != 0 && (static_cast<int64_t>(bias.size()) != N
                             || map_dtype_to_code(bias.dtype()) != out_dtype_code))
        throw std::runtime_error(std::string(name) + ": bias must be empty or a length-N vector in the output dtype");
    if (out_dtype_code < 0 || out_dtype_code > 2)  // allow-list: the launch only supports these
        throw std::runtime_error(std::string(name) + ": out_dtype_code must be 0 (fp32), 1 (fp16), or 2 (bf16)");
    if (map_dtype_to_code(d.dtype()) != out_dtype_code)
        throw std::runtime_error(std::string(name) + ": output dtype does not match out_dtype_code (0=fp32, 1=fp16, 2=bf16)");
    return {M, N, K};
}

// INT8 GEMM + fused dequant (D = acc * xs[m] * ws[n] + bias[n]) via CUTLASS.
// Returns true on success; false means caller falls back to cuBLAS + dequant.
bool cutlass_int8_dequant(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> a,   // [M, K]
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> b,   // [N, K]
    nb::ndarray<float, nb::device::cuda> xs,                // [M] per-row act scale
    nb::ndarray<float, nb::device::cuda> ws,                // [N] per-col weight scale
    nb::ndarray<nb::device::cuda> bias,                     // [N] in the output dtype, or empty
    nb::ndarray<nb::ndim<2>, nb::device::cuda> d,           // [M, N] output
    int out_dtype_code,
    uintptr_t stream_ptr) {
    const auto [M, N, K] = check_int8_gemm_operands("cutlass_int8_dequant", a, b, xs, ws, bias, d, out_dtype_code);
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    const void* bias_ptr = bias.size() > 0 ? bias.data() : nullptr;
    return launch_cutlass_int8_dequant(a.data(), b.data(), xs.data(), ws.data(),
                                       bias_ptr, d.data(), M, N, K, out_dtype_code, stream);
}

// Shared operand checks for the fp16 GEMM bindings: A [M,K], B [N,K], D [M,N],
// all fp16, bias empty or a length-N fp16 vector. Returns (M, N, K).
static std::tuple<int64_t, int64_t, int64_t> check_fp16_gemm_operands(
    const char* name,
    const nb::ndarray<nb::ndim<2>, nb::device::cuda>& a,
    const nb::ndarray<nb::ndim<2>, nb::device::cuda>& b,
    const nb::ndarray<nb::device::cuda>& bias,
    const nb::ndarray<nb::ndim<2>, nb::device::cuda>& d) {
    const int64_t M = a.shape(0);
    const int64_t K = a.shape(1);
    const int64_t N = b.shape(0);
    if (b.shape(1) != K) throw std::runtime_error(std::string(name) + ": K mismatch");
    if (d.shape(0) != M || d.shape(1) != N) throw std::runtime_error(std::string(name) + ": D shape mismatch");
    if (map_dtype_to_code(a.dtype()) != 1 || map_dtype_to_code(b.dtype()) != 1 || map_dtype_to_code(d.dtype()) != 1)
        throw std::runtime_error(std::string(name) + ": all tensors must be fp16");
    if (bias.size() > 0 && (static_cast<int64_t>(bias.size()) != N || map_dtype_to_code(bias.dtype()) != 1))
        throw std::runtime_error(std::string(name) + ": bias must be empty or a length-N fp16 vector");
    return {M, N, K};
}

bool cutlass_fp16_linear(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> a,   // [M, K] half
    nb::ndarray<nb::ndim<2>, nb::device::cuda> b,   // [N, K] half
    nb::ndarray<nb::device::cuda> bias,             // [N] half or empty
    nb::ndarray<nb::ndim<2>, nb::device::cuda> d,   // [M, N] half output
    uintptr_t stream_ptr) {
    const auto [M, N, K] = check_fp16_gemm_operands("cutlass_fp16_linear", a, b, bias, d);
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    return launch_cutlass_fp16_linear(
        a.data(), b.data(), bias.size() > 0 ? bias.data() : nullptr, d.data(), M, N, K, stream);
}

bool cutlass_fp16_linear_residual(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> a,       // [M, K] half
    nb::ndarray<nb::ndim<2>, nb::device::cuda> b,       // [N, K] half
    nb::ndarray<nb::device::cuda> bias,                 // [N] half or empty
    nb::ndarray<nb::device::cuda> rscale,               // [N] half residual branch scale
    nb::ndarray<nb::ndim<2>, nb::device::cuda> resid,   // [M, N] half
    nb::ndarray<nb::ndim<2>, nb::device::cuda> d,       // [M, N] half output
    uintptr_t stream_ptr) {
    const auto [M, N, K] = check_fp16_gemm_operands("cutlass_fp16_linear_residual", a, b, bias, d);
    if (resid.shape(0) != M || resid.shape(1) != N || map_dtype_to_code(resid.dtype()) != 1)
        throw std::runtime_error("cutlass_fp16_linear_residual: residual must be [M, N] fp16");
    if (static_cast<int64_t>(rscale.size()) != N || map_dtype_to_code(rscale.dtype()) != 1)
        throw std::runtime_error("cutlass_fp16_linear_residual: rscale must be a length-N fp16 vector");
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    return launch_cutlass_fp16_linear_residual(
        a.data(), b.data(), bias.size() > 0 ? bias.data() : nullptr, rscale.data(),
        resid.data(), d.data(), M, N, K, stream);
}

bool cutlass_int8_dequant_residual(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> a,   // [M, K]
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> b,   // [N, K]
    nb::ndarray<float, nb::device::cuda> xs,                // [M] per-row act scale
    nb::ndarray<float, nb::device::cuda> ws,                // [N] per-col weight scale
    nb::ndarray<nb::device::cuda> bias,                     // [N] output dtype, or empty
    nb::ndarray<nb::device::cuda> rscale,                   // [N] residual branch scale, output dtype
    nb::ndarray<nb::ndim<2>, nb::device::cuda> resid,       // [M, N], same dtype as d
    nb::ndarray<nb::ndim<2>, nb::device::cuda> d,           // [M, N] output
    int out_dtype_code,
    uintptr_t stream_ptr) {
    const auto [M, N, K] = check_int8_gemm_operands("cutlass_int8_dequant_residual", a, b, xs, ws, bias, d, out_dtype_code);
    if (resid.shape(0) != M || resid.shape(1) != N || map_dtype_to_code(resid.dtype()) != out_dtype_code)
        throw std::runtime_error("cutlass_int8_dequant_residual: residual must be [M, N] in the output dtype");
    if (static_cast<int64_t>(rscale.size()) != N || map_dtype_to_code(rscale.dtype()) != out_dtype_code)
        throw std::runtime_error("cutlass_int8_dequant_residual: rscale must be a length-N vector in the output dtype");
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    return launch_cutlass_int8_dequant_residual(
        a.data(), b.data(), xs.data(), ws.data(), bias.size() > 0 ? bias.data() : nullptr,
        rscale.data(), resid.data(), d.data(), M, N, K, out_dtype_code, stream);
}

bool cutlass_int8_dequant_config(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> a,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> b,
    nb::ndarray<float, nb::device::cuda> xs,
    nb::ndarray<float, nb::device::cuda> ws,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> d,
    int out_dtype_code,
    int config,
    uintptr_t stream_ptr) {
    const int64_t M = a.shape(0);
    const int64_t K = a.shape(1);
    const int64_t N = b.shape(0);
    if (b.shape(1) != K) throw std::runtime_error("cutlass_int8_dequant_config: K mismatch");
    if (d.shape(0) != M || d.shape(1) != N) {
        throw std::runtime_error("cutlass_int8_dequant_config: D shape mismatch");
    }
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    return launch_cutlass_int8_dequant_config(
        a.data(), b.data(), xs.data(), ws.data(), d.data(), M, N, K,
        out_dtype_code, config, stream);
}

float benchmark_cutlass_int8_dequant_config(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> a,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> b,
    nb::ndarray<float, nb::device::cuda> xs,
    nb::ndarray<float, nb::device::cuda> ws,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> d,
    int out_dtype_code,
    int config,
    int iterations,
    uintptr_t stream_ptr) {
    if (iterations <= 0) {
        throw std::runtime_error(
            "benchmark_cutlass_int8_dequant_config: iterations must be positive");
    }
    const int64_t M = a.shape(0);
    const int64_t K = a.shape(1);
    const int64_t N = b.shape(0);
    if (b.shape(1) != K) {
        throw std::runtime_error(
            "benchmark_cutlass_int8_dequant_config: K mismatch");
    }
    if (d.shape(0) != M || d.shape(1) != N) {
        throw std::runtime_error(
            "benchmark_cutlass_int8_dequant_config: D shape mismatch");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    cudaEvent_t start;
    cudaEvent_t end;
    cudaEventCreate(&start);
    cudaEventCreate(&end);
    cudaEventRecord(start, stream);
    for (int iteration = 0; iteration < iterations; ++iteration) {
        if (!launch_cutlass_int8_dequant_config(
                a.data(), b.data(), xs.data(), ws.data(), d.data(), M, N, K,
                out_dtype_code, config, stream)) {
            cudaEventDestroy(start);
            cudaEventDestroy(end);
            return -1.f;
        }
    }
    cudaEventRecord(end, stream);
    cudaEventSynchronize(end);
    float elapsed_ms = 0.f;
    cudaEventElapsedTime(&elapsed_ms, start, end);
    cudaEventDestroy(start);
    cudaEventDestroy(end);
    return elapsed_ms;
}

bool cutlass_turing_int8_dequant(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> a,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> b,
    nb::ndarray<float, nb::device::cuda> xs,
    nb::ndarray<float, nb::device::cuda> ws,
    nb::ndarray<nb::device::cuda> bias,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> d,
    int out_dtype_code,
    uintptr_t stream_ptr) {
    const int64_t M = a.shape(0);
    const int64_t K = a.shape(1);
    const int64_t N = b.shape(0);
    if (b.shape(1) != K) throw std::runtime_error("cutlass_turing_int8_dequant: K mismatch");
    if (d.shape(0) != M || d.shape(1) != N) throw std::runtime_error("cutlass_turing_int8_dequant: D shape mismatch");
    if (xs.size() != static_cast<size_t>(M)) throw std::runtime_error("cutlass_turing_int8_dequant: xs shape mismatch");
    if (ws.size() != 1 && ws.size() != static_cast<size_t>(N)) {
        throw std::runtime_error("cutlass_turing_int8_dequant: ws shape mismatch");
    }
    const void* bias_ptr = bias.size() > 0 ? bias.data() : nullptr;
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    return launch_cutlass_turing_int8_dequant(
        a.data(), b.data(), xs.data(), ws.data(), bias_ptr, d.data(), M, N, K,
        out_dtype_code, ws.size() == 1, stream);
}

// INT4 GEMM + fused dequant via CUTLASS. A and B are packed signed int4 in int8 storage.
// Returns true on success; false means caller falls back to the hand-written int4 kernel.
bool cutlass_int4_dequant(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> a,   // [M, K / 2]
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> b,   // [N, K / 2]
    nb::ndarray<float, nb::device::cuda> xs,                // [M] per-row act scale
    nb::ndarray<float, nb::device::cuda> ws,                // [N] per-col weight scale
    nb::ndarray<nb::device::cuda> bias,                     // [N] in the output dtype, or empty
    nb::ndarray<nb::ndim<2>, nb::device::cuda> d,           // [M, N] output
    int out_dtype_code,
    uintptr_t stream_ptr) {
    const int64_t M = a.shape(0);
    const int64_t K_half = a.shape(1);
    const int64_t N = b.shape(0);
    if (b.shape(1) != K_half) throw std::runtime_error("cutlass_int4_dequant: K mismatch");
    if (d.shape(0) != M || d.shape(1) != N) throw std::runtime_error("cutlass_int4_dequant: D shape mismatch");
    if (xs.size() != static_cast<size_t>(M)) throw std::runtime_error("cutlass_int4_dequant: xs shape mismatch");
    if (ws.size() != static_cast<size_t>(N)) throw std::runtime_error("cutlass_int4_dequant: ws shape mismatch");
    if (out_dtype_code < 0 || out_dtype_code > 2 || map_dtype_to_code(d.dtype()) != out_dtype_code)
        throw std::runtime_error("cutlass_int4_dequant: output dtype does not match out_dtype_code (0=fp32, 1=fp16, 2=bf16)");
    if (bias.size() != 0 && (static_cast<int64_t>(bias.size()) != N
                             || map_dtype_to_code(bias.dtype()) != out_dtype_code))
        throw std::runtime_error("cutlass_int4_dequant: bias must be empty or a length-N vector in the output dtype");
    const int64_t K = K_half * 2;
    if (K % 64 != 0) throw std::runtime_error("cutlass_int4_dequant: K must be divisible by 64");
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    const void* bias_ptr = bias.size() > 0 ? bias.data() : nullptr;
    return launch_cutlass_int4_dequant(a.data(), b.data(), xs.data(), ws.data(),
                                       bias_ptr, d.data(), M, N, K, out_dtype_code, stream);
}

bool cutlass_turing_int4_dequant(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> a,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> b,
    nb::ndarray<float, nb::device::cuda> xs,
    nb::ndarray<float, nb::device::cuda> ws,
    nb::ndarray<nb::device::cuda> bias,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> d,
    int out_dtype_code,
    uintptr_t stream_ptr) {
    const int64_t M = a.shape(0);
    const int64_t K_half = a.shape(1);
    const int64_t N = b.shape(0);
    if (b.shape(1) != K_half) throw std::runtime_error("cutlass_turing_int4_dequant: K mismatch");
    if (d.shape(0) != M || d.shape(1) != N) throw std::runtime_error("cutlass_turing_int4_dequant: D shape mismatch");
    if (xs.size() != static_cast<size_t>(M)) throw std::runtime_error("cutlass_turing_int4_dequant: xs shape mismatch");
    if (ws.size() != static_cast<size_t>(N)) throw std::runtime_error("cutlass_turing_int4_dequant: ws shape mismatch");
    const int64_t K = K_half * 2;
    const void* bias_ptr = bias.size() > 0 ? bias.data() : nullptr;
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    return launch_cutlass_turing_int4_dequant(
        a.data(), b.data(), xs.data(), ws.data(), bias_ptr, d.data(), M, N, K, out_dtype_code, stream);
}

// Code width implied by the packed row: K/2 bytes at 4 bits, 3K/4 at 6. The 6-bit layout is
// uniform (no codebook), needs K % 32 so its rows and high plane stay 8-byte aligned, and
// G a multiple of 16 because its decoder applies one scale per 16-col vector (the C++ twin
// of the eager _check_six_bit_layout rule).
static int64_t w4a8_bits_from_width(int64_t cols, int64_t K, int64_t G, bool has_codebook, const char* who) {
    const int64_t bits = (K > 0) ? (cols * 8) / K : 0;
    if ((bits != 4 && bits != 6) || cols * 8 != K * bits)
        throw std::runtime_error(std::string(who) + ": packed width must be K/2 (4-bit) or 3K/4 (6-bit)");
    if (bits == 6 && (K % 32 != 0 || G < 16 || G % 16 != 0))
        throw std::runtime_error(std::string(who) + ": 6-bit storage needs K % 32 == 0 and G a multiple of 16");
    if (bits == 6 && has_codebook)
        throw std::runtime_error(std::string(who) + ": 6-bit storage has no codebook");
    return bits;
}

// Grouped int4/int6 -> int8 dequant (group scale folded; per-channel scale applied in GEMM).
void dequant_int4_grouped_to_int8(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> qw,     // [N, K*bits/8]
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> s_rel,   // [N, K/G]
    std::optional<nb::ndarray<float, nb::ndim<1>, nb::device::cuda>> codebook,  // [16] or None
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> out,    // [N, K]
    int64_t G, uintptr_t stream_ptr) {
    const int64_t N = qw.shape(0);
    const int64_t K = out.shape(1);
    const int64_t bits = w4a8_bits_from_width(qw.shape(1), K, G, codebook.has_value(), "dequant_int4_grouped");
    if (K % 16 != 0) throw std::runtime_error("dequant_int4_grouped: K must be a multiple of 16");
    if (G < 4 || (16 % G != 0 && G % 16 != 0))
        throw std::runtime_error("dequant_int4_grouped: G must be >=4 and divide 16 or be a multiple of 16");
    if (K % G != 0) throw std::runtime_error("dequant_int4_grouped: K must be divisible by G");
    if (static_cast<int64_t>(s_rel.shape(0)) != N || static_cast<int64_t>(s_rel.shape(1)) != K / G)
        throw std::runtime_error("dequant_int4_grouped: s_rel must have shape [N, K/G]");
    if (static_cast<int64_t>(out.shape(0)) != N)
        throw std::runtime_error("dequant_int4_grouped: out must be [N, K]");
    if (codebook.has_value() && static_cast<int64_t>(codebook->shape(0)) != 16)
        throw std::runtime_error("dequant_int4_grouped: codebook must be [16]");
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    const void* cb = codebook.has_value() ? codebook->data() : nullptr;
    launch_dequant_int4_grouped_to_int8(qw.data(), s_rel.data(), cb, out.data(), N, K, G, bits, stream);
}

// fp8 (e4m3) per-group scale: s_rel passed as raw uint8 bits.
void dequant_int4_grouped_to_int8_e4m3(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> qw,     // [N, K*bits/8]
    nb::ndarray<uint8_t, nb::ndim<2>, nb::device::cuda> s_rel, // [N, K/G] e4m3 bits
    std::optional<nb::ndarray<float, nb::ndim<1>, nb::device::cuda>> codebook,  // [16] or None
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> out,    // [N, K]
    int64_t G, uintptr_t stream_ptr) {
    const int64_t N = qw.shape(0);
    const int64_t K = out.shape(1);
    const int64_t bits = w4a8_bits_from_width(qw.shape(1), K, G, codebook.has_value(), "dequant_int4_grouped");
    if (K % 16 != 0) throw std::runtime_error("dequant_int4_grouped: K must be a multiple of 16");
    if (G < 4 || (16 % G != 0 && G % 16 != 0))
        throw std::runtime_error("dequant_int4_grouped: G must be >=4 and divide 16 or be a multiple of 16");
    if (K % G != 0) throw std::runtime_error("dequant_int4_grouped: K must be divisible by G");
    if (static_cast<int64_t>(s_rel.shape(0)) != N || static_cast<int64_t>(s_rel.shape(1)) != K / G)
        throw std::runtime_error("dequant_int4_grouped: s_rel must have shape [N, K/G]");
    if (static_cast<int64_t>(out.shape(0)) != N)
        throw std::runtime_error("dequant_int4_grouped: out must be [N, K]");
    if (codebook.has_value() && static_cast<int64_t>(codebook->shape(0)) != 16)
        throw std::runtime_error("dequant_int4_grouped: codebook must be [16]");
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    const void* cb = codebook.has_value() ? codebook->data() : nullptr;
    launch_dequant_int4_grouped_to_int8_e4m3(qw.data(), s_rel.data(), cb, out.data(), N, K, G, bits, stream);
}

// Fused W4A8 requantize (group_size=16): rotated weight [N,K] -> packed int4
// [N,K/2] + fp8-e4m3 s_rel [N,K/16] + f32 s_channel [N] in one launch.
void quantize_w4a8_convrot(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> rotated,          // [N, K] fp32/fp16/bf16
    nb::ndarray<float, nb::ndim<1>, nb::device::cuda> codebook,  // [16]
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> packed,   // [N, K/2]
    nb::ndarray<uint8_t, nb::ndim<2>, nb::device::cuda> s_rel,   // [N, K/16] e4m3 bits
    nb::ndarray<float, nb::ndim<1>, nb::device::cuda> s_channel, // [N]
    bool stochastic, uint64_t seed, uintptr_t stream_ptr) {
    const int64_t N = rotated.shape(0);
    const int64_t K = rotated.shape(1);
    const int in_code = map_dtype_to_code(rotated.dtype());
    if (in_code < 0 || in_code > 2)
        throw std::runtime_error("quantize_w4a8_convrot: rotated must be fp32/fp16/bf16");
    if (N <= 0) throw std::runtime_error("quantize_w4a8_convrot: N must be positive");
    if (K <= 0 || K % 16 != 0) throw std::runtime_error("quantize_w4a8_convrot: K must be a positive multiple of 16");
    if (static_cast<int64_t>(packed.shape(0)) != N || static_cast<int64_t>(packed.shape(1)) != K / 2)
        throw std::runtime_error("quantize_w4a8_convrot: packed must be [N, K/2]");
    if (static_cast<int64_t>(s_rel.shape(0)) != N || static_cast<int64_t>(s_rel.shape(1)) != K / 16)
        throw std::runtime_error("quantize_w4a8_convrot: s_rel must be [N, K/16]");
    if (static_cast<int64_t>(s_channel.shape(0)) != N)
        throw std::runtime_error("quantize_w4a8_convrot: s_channel must be [N]");
    if (static_cast<int64_t>(codebook.shape(0)) != 16)
        throw std::runtime_error("quantize_w4a8_convrot: codebook must be [16]");
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    if (!launch_quantize_w4a8_convrot(
            rotated.data(), codebook.data(), packed.data(), s_rel.data(), s_channel.data(),
            N, K, in_code, stochastic, seed, stream))
        throw std::runtime_error(
            "quantize_w4a8_convrot: launch failed (group scales exceed shared memory, or "
            "invalid launch config)");
}

// Fused ConvRot + W4A8/W6A8 requant from the raw weight (see ops/w4a8_gemm.cu). Returns false
// when the row is too long for shared memory: the caller selects a staged fallback.
bool quantize_wxa8_convrot_fused(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> weight,           // [N, K] fp32/fp16/bf16, unrotated
    nb::ndarray<float, nb::device::cuda> codebook,               // [16] at 4 bits, else empty
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> packed,   // [N, K*bits/8]
    nb::ndarray<uint8_t, nb::ndim<2>, nb::device::cuda> s_rel,   // [N, K/group_size] e4m3 bits
    nb::ndarray<float, nb::ndim<1>, nb::device::cuda> s_channel, // [N]
    int64_t bits, int64_t group_size, bool stochastic, uint64_t seed, uintptr_t stream_ptr) {
    const int64_t N = weight.shape(0);
    const int64_t K = weight.shape(1);
    const int in_code = map_dtype_to_code(weight.dtype());
    if (in_code < 0 || in_code > 2)
        throw std::runtime_error("quantize_wxa8_convrot_fused: weight must be fp32/fp16/bf16");
    if (N <= 0) throw std::runtime_error("quantize_wxa8_convrot_fused: N must be positive");
    if (!((bits == 4 && group_size == 16) || (bits == 6 && (group_size == 16 || group_size == 32 || group_size == 64))))
        throw std::runtime_error("quantize_wxa8_convrot_fused: bits/group_size must be 4/16 or 6/{16,32,64}");
    if (K % 256 != 0 || K % group_size != 0)
        throw std::runtime_error("quantize_wxa8_convrot_fused: K must be a multiple of 256 and of group_size");
    if (static_cast<int64_t>(packed.shape(0)) != N || static_cast<int64_t>(packed.shape(1)) != K * bits / 8)
        throw std::runtime_error("quantize_wxa8_convrot_fused: packed must be [N, K*bits/8]");
    if (static_cast<int64_t>(s_rel.shape(0)) != N || static_cast<int64_t>(s_rel.shape(1)) != K / group_size)
        throw std::runtime_error("quantize_wxa8_convrot_fused: s_rel must be [N, K/group_size]");
    if (static_cast<int64_t>(s_channel.shape(0)) != N)
        throw std::runtime_error("quantize_wxa8_convrot_fused: s_channel must be [N]");
    if (bits == 4 && static_cast<int64_t>(codebook.size()) != 16)
        throw std::runtime_error("quantize_wxa8_convrot_fused: codebook must be [16] at 4 bits");
    return launch_quantize_wxa8_convrot_fused(
        weight.data(), bits == 4 ? codebook.data() : nullptr, packed.data(), s_rel.data(), s_channel.data(),
        N, K, static_cast<int>(bits), static_cast<int>(group_size), in_code, stochastic, seed,
        reinterpret_cast<cudaStream_t>(stream_ptr));
}

// Returns the code width (4 or 6) implied by the packed weight row.
static int64_t validate_w4a8_codebook_gemm_contract(
    int64_t M, int64_t N, int64_t K,
    int64_t weight_cols,
    int64_t s_rel_n, int64_t s_rel_groups,
    int64_t s_channel_size, int64_t xs_size,
    int64_t codebook_size, int64_t bias_size, int bias_dtype_code,
    int64_t workspace_rows, int64_t workspace_cols,
    int64_t out_rows, int64_t out_cols,
    const nb::dlpack::dtype& out_dtype,
    int64_t G, int64_t chunk_cols, int out_dtype_code) {
    const int64_t bits = w4a8_bits_from_width(weight_cols, K, G, codebook_size >= 0, "w4a8_codebook_gemm");
    if (K % 16 != 0)
        throw std::runtime_error("w4a8_codebook_gemm: K must be a multiple of 16");
    if (G < 4 || (16 % G != 0 && G % 16 != 0))
        throw std::runtime_error("w4a8_codebook_gemm: G must be >=4 and divide 16 or be a multiple of 16");
    if (K % G != 0)
        throw std::runtime_error("w4a8_codebook_gemm: K must be divisible by G");
    if (xs_size != M)
        throw std::runtime_error("w4a8_codebook_gemm: xs must have M values");
    if (s_rel_n != N || s_rel_groups != K / G)
        throw std::runtime_error("w4a8_codebook_gemm: s_rel must be [N, K/G]");
    if (s_channel_size != N)
        throw std::runtime_error("w4a8_codebook_gemm: s_channel must be [N]");
    if (codebook_size >= 0 && codebook_size != 16)
        throw std::runtime_error("w4a8_codebook_gemm: codebook must be [16]");
    // the strided int8 GEMM reads bias in the output dtype
    if (bias_size >= 0 && (bias_size != N || bias_dtype_code != out_dtype_code))
        throw std::runtime_error("w4a8_codebook_gemm: bias must be [N] in the output dtype");
    if (out_dtype_code < 0 || out_dtype_code > 2)
        throw std::runtime_error("w4a8_codebook_gemm: out_dtype_code must be 0 (fp32), 1 (fp16), or 2 (bf16)");
    if (map_dtype_to_code(out_dtype) != out_dtype_code)
        throw std::runtime_error("w4a8_codebook_gemm: out dtype does not match out_dtype_code (0=fp32, 1=fp16, 2=bf16)");
    if (out_rows != M || out_cols != N)
        throw std::runtime_error("w4a8_codebook_gemm: out must be [M, N]");
    if (chunk_cols > 0) {
        const int64_t required_rows = (chunk_cols < N) ? chunk_cols : N;
        if (workspace_cols != K || workspace_rows < required_rows)
            throw std::runtime_error("w4a8_codebook_gemm: workspace must be [>=min(chunk_cols,N), K] int8");
    }
    return bits;
}

// Chunked fused W4A8: per-chunk (codebook+s_rel) dequant -> L2-hot int8 -> strided int8 GEMM.
bool w4a8_codebook_gemm_chunked(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> xq,        // [M, K] int8 act
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> weight,    // [N, K/2] packed uint4
    nb::ndarray<uint8_t, nb::ndim<2>, nb::device::cuda> s_rel,    // [N, K/G] e4m3 bits
    std::optional<nb::ndarray<float, nb::ndim<1>, nb::device::cuda>> codebook,  // [16] or None
    nb::ndarray<float, nb::ndim<1>, nb::device::cuda> s_channel,  // [N] fp32
    nb::ndarray<float, nb::ndim<1>, nb::device::cuda> xs,         // [M] fp32
    std::optional<nb::ndarray<nb::ndim<1>, nb::device::cuda>> bias,  // [N] in out_dtype, or None
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> workspace, // [chunk_cols, K] int8
    nb::ndarray<nb::ndim<2>, nb::device::cuda> out,               // [M, N] out_dtype
    int64_t G, int64_t chunk_cols, int out_dtype_code, uintptr_t stream_ptr) {
    const int64_t M = xq.shape(0);
    const int64_t K = xq.shape(1);
    const int64_t N = weight.shape(0);
    const int64_t bits = validate_w4a8_codebook_gemm_contract(
        M, N, K,
        weight.shape(1),
        s_rel.shape(0), s_rel.shape(1),
        s_channel.size(), xs.size(),
        codebook.has_value() ? static_cast<int64_t>(codebook->size()) : -1,
        bias.has_value() ? static_cast<int64_t>(bias->size()) : -1,
        bias.has_value() ? map_dtype_to_code(bias->dtype()) : out_dtype_code,
        workspace.shape(0), workspace.shape(1),
        out.shape(0), out.shape(1), out.dtype(),
        G, chunk_cols, out_dtype_code);
    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    const void* cb = codebook.has_value() ? codebook->data() : nullptr;
    const void* bs = bias.has_value() ? bias->data() : nullptr;
    return launch_w4a8_codebook_gemm_chunked(
        xq.data(), weight.data(), s_rel.data(), cb, s_channel.data(), xs.data(), bs,
        workspace.data(), out.data(), M, N, K, G, chunk_cols, bits, out_dtype_code, stream);
}

// Common W4A8 inference path: online ConvRot activation quantization followed by the
// chunked int4 decode + strided INT8 GEMM, coordinated through one Python/native call.
bool w4a8_codebook_linear_chunked(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,             // [M, K] fp32/fp16/bf16
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> xq,       // [M, K]
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> xs,        // [M, 1]
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> weight,   // [N, K/2]
    nb::ndarray<uint8_t, nb::ndim<2>, nb::device::cuda> s_rel,   // [N, K/G]
    std::optional<nb::ndarray<float, nb::ndim<1>, nb::device::cuda>> codebook,
    nb::ndarray<float, nb::ndim<1>, nb::device::cuda> s_channel, // [N]
    std::optional<nb::ndarray<nb::ndim<1>, nb::device::cuda>> bias,  // [N] in out_dtype, or None
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> workspace,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> out,
    int64_t convrot_group_size, int64_t G, int64_t chunk_cols,
    int out_dtype_code, uintptr_t stream_ptr) {
    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);
    const int64_t N = weight.shape(0);
    if (xq.shape(0) != M || xq.shape(1) != K)
        throw std::runtime_error("w4a8_codebook_linear: xq must be [M, K]");
    if (xs.shape(0) != M || xs.shape(1) != 1)
        throw std::runtime_error("w4a8_codebook_linear: xs must be [M, 1]");
    if (input.stride(1) != 1 || input.stride(0) != K
            || xq.stride(1) != 1 || xq.stride(0) != K
            || xs.stride(1) != 1 || xs.stride(0) != 1)
        throw std::runtime_error("w4a8_codebook_linear: input, xq, and xs must be contiguous");
    if (weight.stride(1) != 1 || weight.stride(0) != weight.shape(1)
            || s_rel.stride(1) != 1 || s_rel.stride(0) != s_rel.shape(1)
            || s_channel.stride(0) != 1
            || workspace.stride(1) != 1 || workspace.stride(0) != workspace.shape(1)
            || out.stride(1) != 1 || out.stride(0) != out.shape(1)
            || (codebook.has_value() && codebook->stride(0) != 1)
            || (bias.has_value() && bias->stride(0) != 1))
        throw std::runtime_error("w4a8_codebook_linear: weight metadata, workspace, and out must be contiguous");
    const int input_dtype_code = map_dtype_to_code(input.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2)
        throw std::runtime_error("w4a8_codebook_linear: input must be fp32, fp16, or bf16");
    const int64_t bits = validate_w4a8_codebook_gemm_contract(
        M, N, K,
        weight.shape(1),
        s_rel.shape(0), s_rel.shape(1),
        s_channel.size(), xs.size(),
        codebook.has_value() ? static_cast<int64_t>(codebook->size()) : -1,
        bias.has_value() ? static_cast<int64_t>(bias->size()) : -1,
        bias.has_value() ? map_dtype_to_code(bias->dtype()) : out_dtype_code,
        workspace.shape(0), workspace.shape(1),
        out.shape(0), out.shape(1), out.dtype(),
        G, chunk_cols, out_dtype_code);

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quantize_int8_rowwise_convrot_kernel(
        input.data(), xq.data(), xs.data(), M, K,
        static_cast<int>(convrot_group_size), input_dtype_code,
        false, 0, stream);
    const void* cb = codebook.has_value() ? codebook->data() : nullptr;
    const void* bs = bias.has_value() ? bias->data() : nullptr;
    return launch_w4a8_codebook_gemm_chunked(
        xq.data(), weight.data(), s_rel.data(), cb, s_channel.data(), xs.data(), bs,
        workspace.data(), out.data(), M, N, K, G, chunk_cols, bits, out_dtype_code, stream);
}

bool w4a8_codebook_gemv(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,             // [M, K] fp32/fp16/bf16
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> xq,       // [M, K]
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> xs,        // [M, 1]
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> weight,   // [N, K/2]
    nb::ndarray<uint8_t, nb::ndim<2>, nb::device::cuda> s_rel,   // [N, K/G]
    std::optional<nb::ndarray<float, nb::ndim<1>, nb::device::cuda>> codebook,
    nb::ndarray<float, nb::ndim<1>, nb::device::cuda> s_channel, // [N]
    std::optional<nb::ndarray<nb::ndim<1>, nb::device::cuda>> bias,  // [N] in out_dtype, or None
    nb::ndarray<nb::ndim<2>, nb::device::cuda> out,
    int64_t convrot_group_size, int64_t G,
    int out_dtype_code, uintptr_t stream_ptr) {
    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);
    const int64_t N = weight.shape(0);
    if (xq.shape(0) != M || xq.shape(1) != K || xs.shape(0) != M || xs.shape(1) != 1)
        throw std::runtime_error("w4a8_codebook_gemv: xq must be [M, K] and xs [M, 1]");
    if (input.stride(1) != 1 || input.stride(0) != K
            || xq.stride(1) != 1 || xq.stride(0) != K
            || xs.stride(1) != 1 || xs.stride(0) != 1)
        throw std::runtime_error("w4a8_codebook_gemv: input, xq, and xs must be contiguous");
    if (weight.stride(1) != 1 || weight.stride(0) != weight.shape(1)
            || s_rel.stride(1) != 1 || s_rel.stride(0) != s_rel.shape(1)
            || s_channel.stride(0) != 1
            || out.stride(1) != 1 || out.stride(0) != out.shape(1)
            || (codebook.has_value() && codebook->stride(0) != 1)
            || (bias.has_value() && bias->stride(0) != 1))
        throw std::runtime_error("w4a8_codebook_gemv: weight metadata and out must be contiguous");
    if (G < 16 || (G % 16) != 0)
        throw std::runtime_error("w4a8_codebook_gemv: G must be a multiple of 16");
    const int64_t bits = validate_w4a8_codebook_gemm_contract(
        M, N, K,
        weight.shape(1),
        s_rel.shape(0), s_rel.shape(1),
        s_channel.size(), xs.size(),
        codebook.has_value() ? static_cast<int64_t>(codebook->size()) : -1,
        bias.has_value() ? static_cast<int64_t>(bias->size()) : -1,
        bias.has_value() ? map_dtype_to_code(bias->dtype()) : out_dtype_code,
        /*workspace_rows=*/0, /*workspace_cols=*/0,
        out.shape(0), out.shape(1), out.dtype(),
        G, /*chunk_cols=*/0, out_dtype_code);
    const int input_dtype_code = map_dtype_to_code(input.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2)
        throw std::runtime_error("w4a8_codebook_gemv: input must be fp32, fp16, or bf16");

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quantize_int8_rowwise_convrot_kernel(
        input.data(), xq.data(), xs.data(), M, K,
        static_cast<int>(convrot_group_size), input_dtype_code,
        false, 0, stream);
    return launch_w4a8_codebook_gemv(
        xq.data(), weight.data(), s_rel.data(),
        codebook.has_value() ? codebook->data() : nullptr,
        s_channel.data(), xs.data(),
        bias.has_value() ? bias->data() : nullptr,
        out.data(), M, N, K, G, bits, out_dtype_code, stream);
}

void quantize_int8_rowwise_convrot(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> output,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> scales,
    int64_t group_size,
    bool stochastic,
    uint64_t seed,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);

    if (output.shape(0) != M || output.shape(1) != K) {
        throw std::runtime_error("INT8 rowwise convrot output shape mismatch");
    }
    if (scales.shape(0) != M || scales.shape(1) != 1) {
        throw std::runtime_error("INT8 rowwise convrot scale shape mismatch");
    }
    const int input_dtype_code = map_dtype_to_code(input.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error("Unsupported input dtype for INT8 rowwise convrot quantization");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quantize_int8_rowwise_convrot_kernel(
        input.data(),
        output.data(),
        scales.data(),
        M,
        K,
        static_cast<int>(group_size),
        input_dtype_code,
        stochastic,
        seed,
        stream);
}

void rotate_int8_convrot_weight(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> output,
    int64_t group_size,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);
    if (output.shape(0) != M || output.shape(1) != K) {
        throw std::runtime_error("ConvRot rotate output shape mismatch");
    }

    const int input_dtype_code = map_dtype_to_code(input.dtype());
    const int output_dtype_code = map_dtype_to_code(output.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2 || output_dtype_code < 0 || output_dtype_code > 2) {
        throw std::runtime_error("Unsupported dtype for ConvRot rotate");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_rotate_int8_convrot_weight_kernel(
        input.data(),
        output.data(),
        M,
        K,
        static_cast<int>(group_size),
        input_dtype_code,
        output_dtype_code,
        stream);
}

void quantize_int8_convrot_staged(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> rotated,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> partial_absmax,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> output,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> scales,
    int64_t group_size,
    bool stochastic,
    uint64_t seed,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);
    if (rotated.shape(0) != M || rotated.shape(1) != K) {
        throw std::runtime_error("ConvRot staged rotated shape mismatch");
    }
    if (output.shape(0) != M || output.shape(1) != K) {
        throw std::runtime_error("ConvRot staged output shape mismatch");
    }
    if (scales.shape(0) != M || scales.shape(1) != 1) {
        throw std::runtime_error("ConvRot staged scale shape mismatch");
    }
    const int64_t n_groups = group_size > 0 ? K / group_size : 0;
    if (partial_absmax.shape(0) != M || partial_absmax.shape(1) != n_groups) {
        throw std::runtime_error("ConvRot staged partial absmax shape mismatch");
    }
    const int input_dtype_code = map_dtype_to_code(input.dtype());
    const int rotated_dtype_code = map_dtype_to_code(rotated.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2 || rotated_dtype_code < 0 || rotated_dtype_code > 2) {
        throw std::runtime_error("Unsupported dtype for ConvRot staged quantization");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quantize_int8_convrot_staged_kernel(
        input.data(),
        rotated.data(),
        partial_absmax.data(),
        output.data(),
        scales.data(),
        M,
        K,
        static_cast<int>(group_size),
        input_dtype_code,
        rotated_dtype_code,
        stochastic,
        seed,
        stream);
}

void quantize_int8_rowwise_convrot64(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> output,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> scales,
    int64_t group_size,
    bool stochastic,
    int64_t act_code,
    uint64_t seed,
    nb::ndarray<nb::device::cuda> act_weight,
    double act_eps,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    // K is the activated (quantized) row width; the SwiGLU pair reads a
    // [gate | up] input row twice as wide.
    const int64_t K = output.shape(1);
    const int64_t in_width = (act_code == comfy::kActSwiGLU) ? 2 : 1;

    if (output.shape(0) != M || input.shape(1) != K * in_width) {
        throw std::runtime_error("INT8 rowwise convrot64 output shape mismatch");
    }
    if (scales.shape(0) != M || scales.shape(1) != 1) {
        throw std::runtime_error("INT8 rowwise convrot64 scale shape mismatch");
    }
    const int input_dtype_code = map_dtype_to_code(input.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error("Unsupported input dtype for INT8 rowwise convrot64 quantization");
    }
    const bool has_act_weight = act_weight.data() && act_weight.size() > 0;
    if (act_code == comfy::kActRmsNorm) {
        if (!has_act_weight || act_weight.size() != K) {
            throw std::runtime_error("INT8 rowwise convrot64 rms_norm weight must have K elements");
        }
        if (map_dtype_to_code(act_weight.dtype()) != input_dtype_code) {
            throw std::runtime_error("INT8 rowwise convrot64 rms_norm weight dtype must match the input");
        }
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_quantize_int8_rowwise_convrot64_kernel(
        input.data(),
        output.data(),
        scales.data(),
        M,
        K,
        static_cast<int>(group_size),
        input_dtype_code,
        stochastic,
        static_cast<int>(act_code),
        seed,
        has_act_weight ? act_weight.data() : nullptr,
        static_cast<float>(act_eps),
        stream);
}

void dequantize_int8_linear(
    nb::ndarray<int32_t, nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> x_scales,
    nb::ndarray<float, nb::device::cuda> weight_scales,
    nb::ndarray<nb::device::cuda> bias,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> output,
    int output_dtype_code,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t N = input.shape(1);

    if (x_scales.shape(0) != M || x_scales.shape(1) != 1) {
        throw std::runtime_error("INT8 linear activation scale shape mismatch");
    }
    if (output.shape(0) != M || output.shape(1) != N) {
        throw std::runtime_error("INT8 linear output shape mismatch");
    }
    if (output_dtype_code < 0 || output_dtype_code > 2) {
        throw std::runtime_error("Invalid INT8 linear output dtype code");
    }

    const bool has_bias = bias.data() && bias.size() > 0;
    int bias_dtype_code = output_dtype_code;
    if (has_bias) {
        if (bias.shape(0) != N) {
            throw std::runtime_error("INT8 linear bias shape mismatch");
        }
        bias_dtype_code = map_dtype_to_code(bias.dtype());
        if (bias_dtype_code < 0 || bias_dtype_code > 2) {
            throw std::runtime_error("Unsupported bias dtype for INT8 linear");
        }
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_dequantize_int8_linear_kernel(
        input.data(),
        x_scales.data(),
        weight_scales.data(),
        has_bias ? bias.data() : nullptr,
        output.data(),
        M,
        N,
        static_cast<int64_t>(weight_scales.size()),
        has_bias,
        output_dtype_code,
        bias_dtype_code,
        stream);
}

void int8_gemv_dequant(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> weight,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> x_scales,
    nb::ndarray<float, nb::device::cuda> weight_scales,
    nb::ndarray<nb::device::cuda> bias,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> output,
    int output_dtype_code,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);
    const int64_t N = weight.shape(0);
    if (M != 1 && M != 2) {
        throw std::runtime_error("INT8 GEMV dequant expects M == 1 or M == 2");
    }
    if (weight.shape(1) != K) {
        throw std::runtime_error("INT8 GEMV weight K mismatch");
    }
    if (x_scales.shape(0) != M || x_scales.shape(1) != 1) {
        throw std::runtime_error("INT8 GEMV activation scale shape mismatch");
    }
    if (output.shape(0) != M || output.shape(1) != N) {
        throw std::runtime_error("INT8 GEMV output shape mismatch");
    }
    if (output_dtype_code < 0 || output_dtype_code > 2) {
        throw std::runtime_error("Invalid INT8 GEMV output dtype code");
    }

    const bool has_bias = bias.data() && bias.size() > 0;
    int bias_dtype_code = output_dtype_code;
    if (has_bias) {
        if (bias.shape(0) != N) {
            throw std::runtime_error("INT8 GEMV bias shape mismatch");
        }
        bias_dtype_code = map_dtype_to_code(bias.dtype());
        if (bias_dtype_code < 0 || bias_dtype_code > 2) {
            throw std::runtime_error("Unsupported bias dtype for INT8 GEMV");
        }
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_int8_gemv_dequant_kernel(
        input.data(),
        weight.data(),
        x_scales.data(),
        weight_scales.data(),
        has_bias ? bias.data() : nullptr,
        output.data(),
        M,
        N,
        K,
        static_cast<int64_t>(weight_scales.size()),
        has_bias,
        output_dtype_code,
        bias_dtype_code,
        stream);
}

void int8_linear_m1(
    nb::ndarray<nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> q_scratch,
    nb::ndarray<float, nb::ndim<2>, nb::device::cuda> x_scales,
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> weight,
    nb::ndarray<float, nb::device::cuda> weight_scales,
    nb::ndarray<nb::device::cuda> bias,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> output,
    int output_dtype_code,
    bool convrot,
    int group_size,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);
    const int64_t N = weight.shape(0);
    if (M != 1) {
        throw std::runtime_error("INT8 M=1 linear expects input M == 1");
    }
    if (weight.shape(1) != K) {
        throw std::runtime_error("INT8 M=1 linear weight K mismatch");
    }
    if (q_scratch.shape(0) != 1 || q_scratch.shape(1) != K) {
        throw std::runtime_error("INT8 M=1 linear q scratch shape mismatch");
    }
    if (x_scales.shape(0) != 1 || x_scales.shape(1) != 1) {
        throw std::runtime_error("INT8 M=1 linear activation scale shape mismatch");
    }
    if (output.shape(0) != 1 || output.shape(1) != N) {
        throw std::runtime_error("INT8 M=1 linear output shape mismatch");
    }
    if (output_dtype_code < 0 || output_dtype_code > 2) {
        throw std::runtime_error("Invalid INT8 M=1 linear output dtype code");
    }
    if (convrot && (group_size != 256 || K % 256 != 0)) {
        throw std::runtime_error("INT8 M=1 ConvRot linear requires group_size 256 and K divisible by 256");
    }

    const int input_dtype_code = map_dtype_to_code(input.dtype());
    if (input_dtype_code < 0 || input_dtype_code > 2) {
        throw std::runtime_error("Unsupported input dtype for INT8 M=1 linear");
    }

    const bool has_bias = bias.data() && bias.size() > 0;
    int bias_dtype_code = output_dtype_code;
    if (has_bias) {
        if (bias.shape(0) != N) {
            throw std::runtime_error("INT8 M=1 linear bias shape mismatch");
        }
        bias_dtype_code = map_dtype_to_code(bias.dtype());
        if (bias_dtype_code < 0 || bias_dtype_code > 2) {
            throw std::runtime_error("Unsupported bias dtype for INT8 M=1 linear");
        }
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    if (convrot) {
        launch_quantize_int8_rowwise_convrot64_kernel(
            input.data(),
            q_scratch.data(),
            x_scales.data(),
            M,
            K,
            group_size,
            input_dtype_code,
            false,
            /*act_code=*/0,
            0,
            /*act_weight=*/nullptr,
            /*act_eps=*/0.0f,
            stream);
    } else {
        launch_quantize_int8_rowwise_kernel(
            input.data(),
            q_scratch.data(),
            x_scales.data(),
            M,
            K,
            input_dtype_code,
            false,
            0,
            stream);
    }
    launch_int8_gemv_dequant_kernel(
        q_scratch.data(),
        weight.data(),
        x_scales.data(),
        weight_scales.data(),
        has_bias ? bias.data() : nullptr,
        output.data(),
        M,
        N,
        K,
        static_cast<int64_t>(weight_scales.size()),
        has_bias,
        output_dtype_code,
        bias_dtype_code,
        stream);
}

void dequantize_int8_simple(
    nb::ndarray<int8_t, nb::device::cuda> input,
    nb::ndarray<float, nb::device::cuda> scale,
    nb::ndarray<nb::device::cuda> output,
    int64_t inner_dim,
    int scale_mode,
    uintptr_t stream_ptr) {

    if (output.size() != input.size()) {
        throw std::runtime_error("INT8 simple dequantization output shape mismatch");
    }
    if (scale_mode == 0 && scale.size() != 1) {
        throw std::runtime_error("INT8 simple dequantization scalar scale shape mismatch");
    }
    if (scale_mode == 1 && scale.size() != input.size()) {
        throw std::runtime_error("INT8 simple dequantization elementwise scale shape mismatch");
    }
    if (scale_mode == 2 && (inner_dim <= 0 || input.size() % inner_dim != 0 || scale.size() != input.size() / inner_dim)) {
        throw std::runtime_error("INT8 simple dequantization rowwise scale shape mismatch");
    }
    const int output_dtype_code = map_dtype_to_code(output.dtype());
    if (output_dtype_code < 0 || output_dtype_code > 2) {
        throw std::runtime_error("Unsupported output dtype for INT8 simple dequantization");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_dequantize_int8_simple_kernel(
        input.data(),
        scale.data(),
        output.data(),
        static_cast<int64_t>(input.size()),
        inner_dim,
        scale_mode,
        output_dtype_code,
        stream);
}

void dequantize_int8_convrot_weight(
    nb::ndarray<int8_t, nb::ndim<2>, nb::device::cuda> input,
    nb::ndarray<float, nb::device::cuda> scale,
    nb::ndarray<nb::ndim<2>, nb::device::cuda> output,
    int64_t group_size,
    uintptr_t stream_ptr) {

    const int64_t M = input.shape(0);
    const int64_t K = input.shape(1);
    if (output.shape(0) != M || output.shape(1) != K) {
        throw std::runtime_error("INT8 convrot dequant output shape mismatch");
    }
    if (scale.size() != 1 && scale.size() != static_cast<size_t>(M)) {
        throw std::runtime_error("INT8 convrot dequant scale must be scalar or per-row");
    }
    const int output_dtype_code = map_dtype_to_code(output.dtype());
    if (output_dtype_code < 0 || output_dtype_code > 2) {
        throw std::runtime_error("Unsupported output dtype for INT8 convrot dequantization");
    }

    cudaStream_t stream = reinterpret_cast<cudaStream_t>(stream_ptr);
    launch_dequantize_int8_convrot_kernel(
        input.data(),
        scale.data(),
        output.data(),
        M,
        K,
        static_cast<int64_t>(scale.size()),
        static_cast<int>(group_size),
        output_dtype_code,
        stream);
}

void flash_attention_decode(
    nb::ndarray<nb::ndim<3>, nb::device::cuda> q,
    nb::ndarray<nb::ndim<4>, nb::device::cuda> k,
    nb::ndarray<nb::ndim<4>, nb::device::cuda> v,
    nb::ndarray<int32_t, nb::ndim<1>, nb::device::cuda> kv_lengths,
    nb::ndarray<nb::ndim<3>, nb::device::cuda> output,
    nb::ndarray<float, nb::device::cuda> softmax_lse,
    nb::ndarray<float, nb::device::cuda> softmax_lse_accum,
    nb::ndarray<float, nb::device::cuda> output_accum,
    int num_splits,
    uintptr_t stream_ptr) {
    const int batch = k.shape(0);
    const int kv_capacity = k.shape(1);
    const int heads = k.shape(2);
    const int query_length = q.shape(0) / batch;
    const int head_dim = q.shape(2);
    if (batch <= 0 || kv_capacity <= 0 || heads <= 0 || query_length <= 0 || q.shape(0) != batch * query_length || q.shape(1) != heads || (head_dim != 128 && head_dim != 256)) {
        throw std::runtime_error("Invalid Flash Attention decode dimensions");
    }
    if (v.shape(0) != batch || v.shape(1) != kv_capacity || v.shape(2) != heads || v.shape(3) != head_dim || k.shape(3) != head_dim) {
        throw std::runtime_error("Flash Attention k/v shape mismatch");
    }
    if (output.shape(0) != q.shape(0) || output.shape(1) != heads || output.shape(2) != head_dim || kv_lengths.size() != static_cast<size_t>(batch)) {
        throw std::runtime_error("Flash Attention output or length shape mismatch");
    }
    if (map_dtype_to_code(q.dtype()) != 2 || map_dtype_to_code(k.dtype()) != 2 || map_dtype_to_code(v.dtype()) != 2 || map_dtype_to_code(output.dtype()) != 2) {
        throw std::runtime_error("Flash Attention tensors must have bfloat16 dtype");
    }
    const size_t lse_size = static_cast<size_t>(batch) * heads * query_length;
    if (softmax_lse.size() != lse_size || num_splits < 1 || num_splits > 32 || (num_splits > 1 && (softmax_lse_accum.size() != lse_size * num_splits || output_accum.size() != lse_size * head_dim * num_splits))) {
        throw std::runtime_error("Invalid Flash Attention split workspace");
    }
    if (k.stride(0) != v.stride(0) || k.stride(1) != v.stride(1) || k.stride(2) != v.stride(2) || k.stride(3) != 1 || v.stride(3) != 1 || q.stride(2) != 1 || output.stride(2) != 1) {
        throw std::runtime_error("Unsupported Flash Attention tensor strides");
    }

    launch_flash_decode(
        q.data(), k.data(), v.data(), kv_lengths.data(), output.data(), softmax_lse.data(),
        num_splits > 1 ? softmax_lse_accum.data() : nullptr,
        num_splits > 1 ? output_accum.data() : nullptr,
        batch, query_length, heads, head_dim, kv_capacity, num_splits,
        q.stride(0) * query_length, q.stride(0), q.stride(1),
        k.stride(0), k.stride(1), k.stride(2), reinterpret_cast<cudaStream_t>(stream_ptr));
}

bool gated_delta_decode_fused(
    nb::ndarray<nb::ndim<3>, nb::device::cuda> mixed_qkv,      // [B, C, S] conv+silu output
    nb::ndarray<nb::ndim<3>, nb::device::cuda> x,              // [B, S, Hd]
    nb::ndarray<nb::ndim<2>, nb::device::cuda> w_a,            // [Hv, Hd]
    nb::ndarray<nb::ndim<2>, nb::device::cuda> w_b,            // [Hv, Hd]
    nb::ndarray<float, nb::ndim<1>, nb::device::cuda> dt_bias, // [Hv]
    nb::ndarray<float, nb::ndim<1>, nb::device::cuda> g_decay, // [Hv]
    nb::ndarray<float, nb::ndim<4>, nb::device::cuda> state,   // [B, Hv, DK, DV]
    nb::ndarray<nb::ndim<4>, nb::device::cuda> out,            // [B, S, Hv, DV]
    std::optional<nb::ndarray<float, nb::ndim<5>, nb::device::cuda>> snapshots,  // [S-1, B, Hv, DK, DV]
    nb::ndarray<nb::ndim<3>, nb::device::cuda> z,              // [B, S, Hv*DV] norm gate
    nb::ndarray<nb::ndim<1>, nb::device::cuda> norm_w,         // [DV]
    double eps,
    int64_t key_dim, int64_t num_key_heads, double scale, uintptr_t stream_ptr) {
    const char* who = "gated_delta_decode_fused";
    const int64_t B = mixed_qkv.shape(0), C = mixed_qkv.shape(1), S = mixed_qkv.shape(2);
    const int64_t Hv = state.shape(1), DK = state.shape(2), DV = state.shape(3);
    const int64_t Hd = x.shape(2);
    const int dtype_code = map_dtype_to_code(mixed_qkv.dtype());
    if (dtype_code < 0 || dtype_code > 2 || map_dtype_to_code(x.dtype()) != dtype_code
        || map_dtype_to_code(w_a.dtype()) != dtype_code || map_dtype_to_code(w_b.dtype()) != dtype_code
        || map_dtype_to_code(out.dtype()) != dtype_code || map_dtype_to_code(z.dtype()) != dtype_code
        || map_dtype_to_code(norm_w.dtype()) != dtype_code)
        throw std::runtime_error(std::string(who) + ": mixed_qkv, x, w_a, w_b, z, norm_w and out must share a fp32/fp16/bf16 dtype");
    if (x.shape(0) != B || x.shape(1) != S || w_a.shape(0) != Hv || w_a.shape(1) != Hd
        || w_b.shape(0) != Hv || w_b.shape(1) != Hd || dt_bias.shape(0) != Hv || g_decay.shape(0) != Hv
        || state.shape(0) != B || out.shape(0) != B || out.shape(1) != S || out.shape(2) != Hv || out.shape(3) != DV
        || z.shape(0) != B || z.shape(1) != S || z.shape(2) != Hv * DV || norm_w.shape(0) != DV
        || num_key_heads <= 0 || Hv % num_key_heads != 0 || C < 2 * key_dim + Hv * DV
        || key_dim != num_key_heads * DK)
        throw std::runtime_error(std::string(who) + ": shape mismatch");
    need_contiguous(mixed_qkv, who, "mixed_qkv");
    need_contiguous(x, who, "x");
    need_contiguous(w_a, who, "w_a");
    need_contiguous(w_b, who, "w_b");
    need_contiguous(dt_bias, who, "dt_bias");
    need_contiguous(g_decay, who, "g_decay");
    need_contiguous(state, who, "state");
    need_contiguous(out, who, "out");
    need_contiguous(z, who, "z");
    need_contiguous(norm_w, who, "norm_w");
    void* snap_ptr = nullptr;
    if (snapshots.has_value() && S > 1) {
        auto& sn = *snapshots;
        if (sn.shape(0) < S - 1 || sn.shape(1) != B || sn.shape(2) != Hv || sn.shape(3) != DK || sn.shape(4) != DV)
            throw std::runtime_error(std::string(who) + ": snapshot shape mismatch");
        need_contiguous(sn, who, "snapshots");
        snap_ptr = sn.data();
    }
    return launch_gated_delta_decode_fused(
        mixed_qkv.data(), x.data(), w_a.data(), w_b.data(), dt_bias.data(), g_decay.data(),
        state.data(), out.data(), snap_ptr, z.data(), norm_w.data(), static_cast<float>(eps),
        B, Hv, num_key_heads, S, DK, DV, C, Hd, key_dim, static_cast<float>(scale), dtype_code,
        reinterpret_cast<cudaStream_t>(stream_ptr));
}

bool deltanet_conv_step(
    nb::ndarray<nb::ndim<3>, nb::device::cuda> proj,        // [B, S, C]
    nb::ndarray<nb::ndim<3>, nb::device::cuda> conv_state,  // [B, C, KS-1] in/out
    nb::ndarray<nb::ndim<2>, nb::device::cuda> conv_w,      // [C, KS]
    std::optional<nb::ndarray<nb::ndim<1>, nb::device::cuda>> conv_b,  // [C]
    nb::ndarray<nb::ndim<3>, nb::device::cuda> conv_out,    // [B, C, S]
    std::optional<nb::ndarray<nb::ndim<4>, nb::device::cuda>> conv_snaps,  // [S-1, B, C, KS-1]
    uintptr_t stream_ptr) {
    const char* who = "deltanet_conv_step";
    const int64_t B = proj.shape(0), S = proj.shape(1), C = proj.shape(2);
    const int64_t L = conv_state.shape(2), KS = conv_w.shape(1);
    const int dtype_code = map_dtype_to_code(proj.dtype());
    if (dtype_code < 0 || dtype_code > 2 || map_dtype_to_code(conv_state.dtype()) != dtype_code
        || map_dtype_to_code(conv_w.dtype()) != dtype_code || map_dtype_to_code(conv_out.dtype()) != dtype_code
        || (conv_b.has_value() && map_dtype_to_code(conv_b->dtype()) != dtype_code))
        throw std::runtime_error(std::string(who) + ": all tensors must share a fp32/fp16/bf16 dtype");
    if (conv_state.shape(0) != B || conv_state.shape(1) != C || L != KS - 1 || conv_w.shape(0) != C
        || conv_out.shape(0) != B || conv_out.shape(1) != C || conv_out.shape(2) != S
        || (conv_b.has_value() && conv_b->shape(0) != C))
        throw std::runtime_error(std::string(who) + ": shape mismatch");
    need_contiguous(proj, who, "proj");
    need_contiguous(conv_state, who, "conv_state");
    need_contiguous(conv_w, who, "conv_w");
    need_contiguous(conv_out, who, "conv_out");
    if (conv_b.has_value())
        need_contiguous(*conv_b, who, "conv_b");
    void* snaps = nullptr;
    if (conv_snaps.has_value() && S > 1) {
        auto& sn = *conv_snaps;
        if (map_dtype_to_code(sn.dtype()) != dtype_code || sn.shape(0) < S - 1 || sn.shape(1) != B
            || sn.shape(2) != C || sn.shape(3) != L)
            throw std::runtime_error(std::string(who) + ": snapshots must be [>=S-1, B, C, KS-1] in the activation dtype");
        need_contiguous(sn, who, "conv_snaps");
        snaps = sn.data();
    }
    return launch_deltanet_conv_step(
        proj.data(), conv_state.data(), conv_w.data(), conv_b.has_value() ? conv_b->data() : nullptr,
        conv_out.data(), snaps, B, C, S, KS, dtype_code, reinterpret_cast<cudaStream_t>(stream_ptr));
}

NB_MODULE(_C, m) {
    m.doc() = "comfy_kitchen CUDA kernels - nanobind + DLPack interface (NO PyTorch C++ dependencies)";
    
    m.def("quantize_per_tensor_fp8", &quantize_per_tensor_fp8,
          "Quantize to FP8 using nanobind ndarrays",
          nb::arg("input"),
          nb::arg("scale"),
          nb::arg("output"),
          nb::arg("input_dtype_code"),
          nb::arg("output_dtype_code"),
          nb::arg("numel"),
          nb::arg("stream_ptr"));
    
    m.def("dequantize_per_tensor_fp8", &dequantize_per_tensor_fp8,
          "Dequantize from FP8 using nanobind ndarrays",
          nb::arg("input"),
          nb::arg("scale"),
          nb::arg("output"),
          nb::arg("input_dtype_code"),
          nb::arg("output_dtype_code"),
          nb::arg("numel"),
          nb::arg("stream_ptr"));

    m.def("stochastic_round_fp8", &stochastic_round_fp8,
          "Stochastically round to FP8, overwriting RNG storage with FP8 output",
          nb::arg("rng_and_output"),
          nb::arg("input"),
          nb::arg("output_dtype_code"),
          nb::arg("numel"),
          nb::arg("stream_ptr"));
    
    m.def("cublas_gemm_blockwise_fp4", &cublas_gemm_blockwise_fp4,
          "cuBLAS FP4 GEMM with block-wise scaling",
          nb::arg("b"),
          nb::arg("block_scale_b"),
          nb::arg("a"),
          nb::arg("block_scale_a"),
          nb::arg("out"),
          nb::arg("out_dtype_code"),
          nb::arg("bias"),
          nb::arg("workspace"),
          nb::arg("accumulate"),
          nb::arg("alpha"),
          nb::arg("stream_ptr"));

    m.def("cublas_gemm_int8", &cublas_gemm_int8,
          "INT8 GEMM using cuBLASLt IMMA tensor cores (SM >= 7.5)",
          nb::arg("a"),
          nb::arg("b"),
          nb::arg("c"),
          nb::arg("workspace"),
          nb::arg("stream_ptr"));

    m.def("quantize_int8_rowwise", &quantize_int8_rowwise,
          "Rowwise INT8 quantization for CUDA activations",
          nb::arg("input"),
          nb::arg("output"),
          nb::arg("scales"),
          nb::arg("stochastic"),
          nb::arg("seed"),
          nb::arg("stream_ptr"));

    m.def("quantize_int4_rowwise", &quantize_int4_rowwise,
          "Rowwise signed INT4 quantization for CUDA activations/weights",
          nb::arg("input"),
          nb::arg("output"),
          nb::arg("scales"),
          nb::arg("stochastic"),
          nb::arg("seed"),
          nb::arg("stream_ptr"));

    m.def("quantize_int4_rowwise_convrot64", &quantize_int4_rowwise_convrot64,
          "Fused regular ConvRot-256 activation rotation plus rowwise signed INT4 quantization",
          nb::arg("input"),
          nb::arg("output"),
          nb::arg("scales"),
          nb::arg("group_size"),
          nb::arg("stochastic"),
          nb::arg("seed"),
          nb::arg("stream_ptr"));

    m.def("quantize_int4_rowwise_convrot64_to_int8", &quantize_int4_rowwise_convrot64_to_int8,
          "Fused ConvRot-256 activation rotation plus rowwise INT4-scale quantization into INT8 storage",
          nb::arg("input"),
          nb::arg("output"),
          nb::arg("scales"),
          nb::arg("group_size"),
          nb::arg("stochastic"),
          nb::arg("seed"),
          nb::arg("stream_ptr"));

    m.def("dequantize_int4_convrot64", &dequantize_int4_convrot64,
          "Fused packed signed INT4 dequantization plus regular ConvRot-256 inverse rotation",
          nb::arg("input"),
          nb::arg("scales"),
          nb::arg("output"),
          nb::arg("group_size"),
          nb::arg("stream_ptr"));

    m.def("int4_linear", &int4_linear,
          "Signed INT4 GEMM with rowwise x colwise dequantization, bias, and output cast",
          nb::arg("act"),
          nb::arg("weight"),
          nb::arg("x_scales"),
          nb::arg("weight_scales"),
          nb::arg("bias"),
          nb::arg("output"),
          nb::arg("output_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("unpack_int4_to_int8", &unpack_int4_to_int8,
          "Unpack row-major packed signed INT4 matrix to row-major INT8 matrix",
          nb::arg("input"),
          nb::arg("output"),
          nb::arg("stream_ptr"));

    m.def("int4_weight_int8_act_gemv_dequant", &int4_weight_int8_act_gemv_dequant,
          "M=1 GEMV using INT8 activation and packed row-major INT4 weight with fused dequant",
          nb::arg("input"),
          nb::arg("weight"),
          nb::arg("x_scales"),
          nb::arg("weight_scales"),
          nb::arg("bias"),
          nb::arg("output"),
          nb::arg("output_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("int4_weight_int8_act_gemm_dequant_chunked", &int4_weight_int8_act_gemm_dequant_chunked,
          "Chunked INT8 GEMM using INT8 activation and packed row-major INT4 weight with fused dequant",
          nb::arg("input"),
          nb::arg("weight"),
          nb::arg("x_scales"),
          nb::arg("weight_scales"),
          nb::arg("bias"),
          nb::arg("output"),
          nb::arg("weight_workspace"),
          nb::arg("acc_workspace"),
          nb::arg("cublas_workspace"),
          nb::arg("chunk_cols"),
          nb::arg("allow_sm80_cutlass"),
          nb::arg("output_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("cutlass_int8_dequant", &cutlass_int8_dequant,
          "INT8 GEMM + fused rowwise x colwise dequant + bias via CUTLASS; false -> fall back to cuBLAS",
          nb::arg("a"),
          nb::arg("b"),
          nb::arg("xs"),
          nb::arg("ws"),
          nb::arg("bias"),
          nb::arg("d"),
          nb::arg("out_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("cutlass_fp16_linear", &cutlass_fp16_linear,
          "FP16 GEMM with FP16 accumulators via CUTLASS (D = A @ B^T + bias); "
          "false -> caller falls back to cuBLAS.",
          nb::arg("a"),
          nb::arg("b"),
          nb::arg("bias"),
          nb::arg("d"),
          nb::arg("stream_ptr"));

    m.def("cutlass_fp16_linear_residual", &cutlass_fp16_linear_residual,
          "FP16-accumulate GEMM with a fused residual: "
          "D = resid + rscale * (A @ B^T + bias); false -> caller falls back.",
          nb::arg("a"),
          nb::arg("b"),
          nb::arg("bias"),
          nb::arg("rscale"),
          nb::arg("resid"),
          nb::arg("d"),
          nb::arg("stream_ptr"));

    m.def("cutlass_int8_dequant_residual", &cutlass_int8_dequant_residual,
          "INT8 GEMM + fused dequant + bias + per-channel-scaled residual add "
          "(D = resid + rscale * (acc * xs * ws + bias)) via CUTLASS; false -> caller falls back",
          nb::arg("a"),
          nb::arg("b"),
          nb::arg("xs"),
          nb::arg("ws"),
          nb::arg("bias"),
          nb::arg("rscale"),
          nb::arg("resid"),
          nb::arg("d"),
          nb::arg("out_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("cutlass_int8_selected_config", &cutlass_int8_selected_config,
          "The fused INT8 GEMM tile config the shape heuristic picks for (M, N, K); -1 without CUTLASS",
          nb::arg("m"), nb::arg("n"), nb::arg("k"));

    m.def("cutlass_int8_dequant_config", &cutlass_int8_dequant_config,
          "Benchmark one fused CUTLASS INT8 kernel configuration",
          nb::arg("a"),
          nb::arg("b"),
          nb::arg("xs"),
          nb::arg("ws"),
          nb::arg("d"),
          nb::arg("out_dtype_code"),
          nb::arg("config"),
          nb::arg("stream_ptr"));

    m.def("benchmark_cutlass_int8_dequant_config",
          &benchmark_cutlass_int8_dequant_config,
          "Time a tight loop of one fused CUTLASS INT8 kernel configuration",
          nb::arg("a"),
          nb::arg("b"),
          nb::arg("xs"),
          nb::arg("ws"),
          nb::arg("d"),
          nb::arg("out_dtype_code"),
          nb::arg("config"),
          nb::arg("iterations"),
          nb::arg("stream_ptr"));

    m.def("cutlass_turing_int8_dequant", &cutlass_turing_int8_dequant,
          "Turing INT8 tensor-core GEMM with fused row/column dequantization",
          nb::arg("a"),
          nb::arg("b"),
          nb::arg("xs"),
          nb::arg("ws"),
          nb::arg("bias"),
          nb::arg("d"),
          nb::arg("out_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("cutlass_int4_dequant", &cutlass_int4_dequant,
          "INT4 GEMM + fused rowwise x colwise dequant + bias via CUTLASS; false -> fall back to hand kernel",
          nb::arg("a"),
          nb::arg("b"),
          nb::arg("xs"),
          nb::arg("ws"),
          nb::arg("bias"),
          nb::arg("d"),
          nb::arg("out_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("cutlass_turing_int4_dequant", &cutlass_turing_int4_dequant,
          "Turing packed INT4 tensor-core GEMM with fused row/column dequantization",
          nb::arg("a"),
          nb::arg("b"),
          nb::arg("xs"),
          nb::arg("ws"),
          nb::arg("bias"),
          nb::arg("d"),
          nb::arg("out_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("dequant_int4_grouped_to_int8", &dequant_int4_grouped_to_int8,
          "Grouped int4/int6 -> int8 dequant (group scale folded into int8); optional 16-entry codebook (4-bit)",
          nb::arg("qw"), nb::arg("s_rel"), nb::arg("codebook").none(), nb::arg("out"),
          nb::arg("g"), nb::arg("stream_ptr"));

    m.def("dequant_int4_grouped_to_int8_e4m3", &dequant_int4_grouped_to_int8_e4m3,
          "Grouped int4/int6 -> int8 dequant with fp8 e4m3 per-group scale; optional 16-entry codebook (4-bit)",
          nb::arg("qw"), nb::arg("s_rel"), nb::arg("codebook").none(), nb::arg("out"),
          nb::arg("g"), nb::arg("stream_ptr"));

    m.def("quantize_w4a8_convrot", &quantize_w4a8_convrot,
          "Fused W4A8 requant (group_size=16): rotated weight -> packed int4 + fp8 s_rel + f32 s_channel",
          nb::arg("rotated"), nb::arg("codebook"), nb::arg("packed"), nb::arg("s_rel"),
          nb::arg("s_channel"), nb::arg("stochastic"), nb::arg("seed"), nb::arg("stream_ptr"));

    m.def("quantize_wxa8_convrot_fused", &quantize_wxa8_convrot_fused,
          "Fused ConvRot + W4A8/W6A8 requant from the raw weight; false -> row too long for shared memory.",
          nb::arg("weight"), nb::arg("codebook"), nb::arg("packed"), nb::arg("s_rel"), nb::arg("s_channel"),
          nb::arg("bits"), nb::arg("group_size"), nb::arg("stochastic"), nb::arg("seed"), nb::arg("stream_ptr"));

    m.def("w4a8_codebook_gemm_chunked", &w4a8_codebook_gemm_chunked,
          "Chunked fused W4A8: per-chunk codebook+s_rel dequant -> L2-hot int8 -> strided int8 GEMM",
          nb::arg("xq"), nb::arg("weight"), nb::arg("s_rel"), nb::arg("codebook").none(),
          nb::arg("s_channel"), nb::arg("xs"), nb::arg("bias").none(), nb::arg("workspace"),
          nb::arg("out"), nb::arg("g"), nb::arg("chunk_cols"), nb::arg("out_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("w4a8_codebook_linear_chunked", &w4a8_codebook_linear_chunked,
          "Fused W4A8 inference orchestration: ConvRot activation quantization followed by chunked decode/GEMM",
          nb::arg("input"), nb::arg("xq"), nb::arg("xs"), nb::arg("weight"),
          nb::arg("s_rel"), nb::arg("codebook").none(), nb::arg("s_channel"),
          nb::arg("bias").none(), nb::arg("workspace"), nb::arg("out"),
          nb::arg("convrot_group_size"), nb::arg("g"), nb::arg("chunk_cols"),
          nb::arg("out_dtype_code"), nb::arg("stream_ptr"));

    m.def("w4a8_codebook_gemv", &w4a8_codebook_gemv,
          "Fused W4A8 decode GEMV (M<=8): in-register int4+codebook dequant, no workspace",
          nb::arg("input"), nb::arg("xq"), nb::arg("xs"), nb::arg("weight"),
          nb::arg("s_rel"), nb::arg("codebook").none(), nb::arg("s_channel"),
          nb::arg("bias").none(), nb::arg("out"),
          nb::arg("convrot_group_size"), nb::arg("g"),
          nb::arg("out_dtype_code"), nb::arg("stream_ptr"));

    m.def("quantize_int8_rowwise_convrot", &quantize_int8_rowwise_convrot,
          "Fused ConvRot Hadamard rotation + rowwise INT8 quantization",
          nb::arg("input"),
          nb::arg("output"),
          nb::arg("scales"),
          nb::arg("group_size"),
          nb::arg("stochastic"),
          nb::arg("seed"),
          nb::arg("stream_ptr"));

    m.def("rotate_int8_convrot_weight", &rotate_int8_convrot_weight,
          "ConvRot Hadamard weight rotation",
          nb::arg("input"),
          nb::arg("output"),
          nb::arg("group_size"),
          nb::arg("stream_ptr"));

    m.def("quantize_int8_convrot_staged", &quantize_int8_convrot_staged,
          "ConvRot rotation with partial absmax followed by INT8 rowwise quantization",
          nb::arg("input"),
          nb::arg("rotated"),
          nb::arg("partial_absmax"),
          nb::arg("output"),
          nb::arg("scales"),
          nb::arg("group_size"),
          nb::arg("stochastic"),
          nb::arg("seed"),
          nb::arg("stream_ptr"));

    m.def("quantize_int8_rowwise_convrot64", &quantize_int8_rowwise_convrot64,
          "Fused ConvRot rowwise INT8 quantization using 64-lane FHT groups. "
          "act_code applies an activation to the input first (the comfy::kAct* "
          "codes in input_act_codes.h: none, gelu tanh-approx, swiglu, "
          "rms_norm), folding it into the quantizer instead of round-tripping "
          "it through HBM. rms_norm "
          "reads its K-element weight from act_weight (same dtype as the "
          "input; pass an empty tensor otherwise) and eps from act_eps.",
          nb::arg("input"),
          nb::arg("output"),
          nb::arg("scales"),
          nb::arg("group_size"),
          nb::arg("stochastic"),
          nb::arg("act_code"),
          nb::arg("seed"),
          nb::arg("act_weight"),
          nb::arg("act_eps"),
          nb::arg("stream_ptr"));

    m.def("dequantize_int8_linear", &dequantize_int8_linear,
          "Fused INT8 linear dequantization, bias, and output cast",
          nb::arg("input"),
          nb::arg("x_scales"),
          nb::arg("weight_scales"),
          nb::arg("bias"),
          nb::arg("output"),
          nb::arg("output_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("int8_gemv_dequant", &int8_gemv_dequant,
          "INT8 GEMV with fused rowwise x colwise dequantization, bias, and output cast",
          nb::arg("input"),
          nb::arg("weight"),
          nb::arg("x_scales"),
          nb::arg("weight_scales"),
          nb::arg("bias"),
          nb::arg("output"),
          nb::arg("output_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("int8_linear_m1", &int8_linear_m1,
          "M=1 INT8 linear: activation quantization followed by GEMV/dequant",
          nb::arg("input"),
          nb::arg("q_scratch"),
          nb::arg("x_scales"),
          nb::arg("weight"),
          nb::arg("weight_scales"),
          nb::arg("bias"),
          nb::arg("output"),
          nb::arg("output_dtype_code"),
          nb::arg("convrot"),
          nb::arg("group_size"),
          nb::arg("stream_ptr"));

    m.def("dequantize_int8_simple", &dequantize_int8_simple,
          "INT8 dequantization to float32",
          nb::arg("input"),
          nb::arg("scale"),
          nb::arg("output"),
          nb::arg("inner_dim"),
          nb::arg("scale_mode"),
          nb::arg("stream_ptr"));

    m.def("dequantize_int8_convrot_weight", &dequantize_int8_convrot_weight,
          "INT8 ConvRot weight dequantization to float32",
          nb::arg("input"),
          nb::arg("scale"),
          nb::arg("output"),
          nb::arg("group_size"),
          nb::arg("stream_ptr"));

    m.def("apply_rope", &apply_rope,
          "Apply Rotary Position Embedding (RoPE) using nanobind ndarrays",
          nb::arg("xq"),
          nb::arg("freqs"),
          nb::arg("xq_out"),
          nb::arg("xk") = nullptr,
          nb::arg("xk_out") = nullptr,
          nb::arg("stream_ptr"),
          nb::arg("split_half") = false);

    m.def("rms_rope", &rms_rope,
          "Fused RMSNorm and interleaved RoPE for Q/K tensors", nb::arg("q"),
          nb::arg("k"), nb::arg("freqs"), nb::arg("q_scale"),
          nb::arg("k_scale"), nb::arg("q_out"), nb::arg("k_out"),
          nb::arg("epsilon"), nb::arg("stream_ptr"),
          nb::arg("split_half") = false, nb::arg("rot_dim") = 0);

    m.def("rms_rope1", &rms_rope1, "Fused RMSNorm and RoPE for a single tensor",
          nb::arg("q"), nb::arg("freqs"), nb::arg("q_scale"), nb::arg("q_out"),
          nb::arg("epsilon"), nb::arg("stream_ptr"),
          nb::arg("split_half") = false);

    m.def("quantize_nvfp4", &quantize_nvfp4,
          "Quantize to FP4 E2M1 with E4M3 block scales using cuBLAS tiled layout",
          nb::arg("input"),
          nb::arg("global_scale"),
          nb::arg("output"),
          nb::arg("block_scales"),
          nb::arg("epsilon"),
          nb::arg("pad_16x") = false,
          nb::arg("hi_first") = true,
          nb::arg("stream_ptr"));

    m.def("dequantize_nvfp4", &dequantize_nvfp4,
          "Dequantize from FP4 E2M1 with E4M3 block scales using cuBLAS tiled layout",
          nb::arg("input"),
          nb::arg("global_scale"),
          nb::arg("block_scales"),
          nb::arg("output"),
          nb::arg("output_dtype_code"),
          nb::arg("hi_first") = true,
          nb::arg("stream_ptr"));

    m.def("quantize_mxfp8", &quantize_mxfp8,
          "Quantize to FP8 E4M3 with E8M0 block scales using cuBLAS tiled layout",
          nb::arg("input"),
          nb::arg("output"),
          nb::arg("block_scales"),
          nb::arg("pad_32x") = false,
          nb::arg("stream_ptr"));

    m.def("_quant_v_int8", &quant_v_int8,
          "Quantize V [B,H,N,D] to signed INT8 rows [B*H*D,padded_N] with per-row scale",
          nb::arg("v"),
          nb::arg("out"),
          nb::arg("scale"),
          nb::arg("padded_n"),
          nb::arg("input_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("_quant_qk_per_thread_int8", &quant_qk_per_thread_int8,
          "INT8 per-thread quant for Q and K (HND), same tiling as Triton quant_per_thread",
          nb::arg("q"),
          nb::arg("q_int8"),
          nb::arg("q_scale"),
          nb::arg("k"),
          nb::arg("k_int8"),
          nb::arg("k_scale"),
          nb::arg("blk_q"),
          nb::arg("warp_q"),
          nb::arg("blk_k"),
          nb::arg("warp_k"),
          nb::arg("input_dtype_code"),
          nb::arg("stream_ptr"),
          nb::arg("anchor_indices_ptr"));

    m.def("_sage_attn", &sage_attn,
          "Pure INT8 QK / U8-softmax / INT8-V attention kernel",
          nb::arg("q"),
          nb::arg("k"),
          nb::arg("v"),
          nb::arg("o"),
          nb::arg("q_scale"),
          nb::arg("k_scale"),
          nb::arg("v_scale"),
          nb::arg("sm_scale"),
          nb::arg("output_dtype_code"),
          nb::arg("stream_ptr"));

    m.def("sage_prepare_key_mask", &sage_prepare_key_mask,
          nb::arg("mask"), nb::arg("packed"), nb::arg("stream_ptr"));

    m.def("sage_sdpa_quantize", &sage_sdpa_quantize,
          "Prequantize Q/K/V for split pure-INT8 SDPA",
          nb::arg("q"),
          nb::arg("k"),
          nb::arg("v"),
          nb::arg("q_int8"),
          nb::arg("q_scale"),
          nb::arg("k_int8"),
          nb::arg("k_scale"),
          nb::arg("v_int8"),
          nb::arg("v_scale"),
          nb::arg("cta_k"),
          nb::arg("input_dtype_code"),
          nb::arg("stream_ptr"),
          nb::arg("anchor_indices_ptr"));

    m.def("sage_sdpa_prequantized", &sage_sdpa_prequantized,
          "Run pure-INT8 SDPA from prequantized Q/K/V",
          nb::arg("q_int8"),
          nb::arg("k_int8"),
          nb::arg("v_int8"),
          nb::arg("o"),
          nb::arg("q_scale"),
          nb::arg("k_scale"),
          nb::arg("v_scale"),
          nb::arg("cta_k"),
          nb::arg("sm_scale"),
          nb::arg("output_dtype_code"),
          nb::arg("stream_ptr"),
          nb::arg("attn_mask"));

    m.def("sage_sdpa", &sage_sdpa,
          "Fused pure-INT8 SDPA: quant_qk + quant_v + attention in one call",
          nb::arg("q"),
          nb::arg("k"),
          nb::arg("v"),
          nb::arg("o"),
          nb::arg("q_int8"),
          nb::arg("q_scale"),
          nb::arg("k_int8"),
          nb::arg("k_scale"),
          nb::arg("v_int8"),
          nb::arg("v_scale"),
          nb::arg("sm_scale"),
          nb::arg("input_dtype_code"),
          nb::arg("output_dtype_code"),
          nb::arg("stream_ptr"),
          nb::arg("anchor_indices_ptr"),
          nb::arg("attn_mask"),
          nb::arg("cta_k"));

    m.def("svdquant_quantize_w4a4", &svdquant_quantize_w4a4,
          "SVDQuant W4A4: smooth + int4 quantize (LoRA-down is external). "
          "act_unsigned selects scale=max/15 + clamp [0,15] for u4 MMA downstream; "
          "caller must pre-shift x to be non-negative before calling (model-level concern).",
          nb::arg("x"),
          nb::arg("smooth"),
          nb::arg("lora_down"),
          nb::arg("q_x"),
          nb::arg("ascales"),
          nb::arg("lora_act"),
          nb::arg("act_unsigned"),
          nb::arg("stream_ptr"));

    m.def("svdquant_scaled_mm_w4a4", &svdquant_scaled_mm_w4a4,
          "SVDQuant W4A4: int4 GEMM with per-group dequant",
          nb::arg("act"),
          nb::arg("wgt"),
          nb::arg("ascales"),
          nb::arg("wscales"),
          nb::arg("lora_act_in"),
          nb::arg("lora_up"),
          nb::arg("bias"),
          nb::arg("out"),
          nb::arg("act_unsigned"),
          nb::arg("fast_accum"),
          nb::arg("shared_scale"),
          nb::arg("fuse_lora"),
          nb::arg("stream_ptr"));

    m.def("awq_w4a16", &awq_w4a16,
          "AWQ W4A16: int4 weight @ fp activation (kitchen-native row-major). "
          "Internal M-routing picks gemv (M ≤ 8) vs gemm. bias / LoRA-up are "
          "applied externally; this kernel only does the dequant + matmul.",
          nb::arg("x"),
          nb::arg("qweight"),
          nb::arg("wscales"),
          nb::arg("wzeros"),
          nb::arg("out"),
          nb::arg("group_size"),
          nb::arg("stream_ptr"));

    m.def("na3d", &na3d,
          "Fused 3D neighborhood attention (NATTEN na3d semantics)",
          nb::arg("q"), nb::arg("k"), nb::arg("v"), nb::arg("out"),
          nb::arg("batch"), nb::arg("t_size"), nb::arg("h_size"), nb::arg("w_size"),
          nb::arg("num_heads"), nb::arg("head_dim"),
          nb::arg("kt"), nb::arg("kh"), nb::arg("kw"),
          nb::arg("causal_t"), nb::arg("causal_h"), nb::arg("causal_w"),
          nb::arg("scale"), nb::arg("dtype_code"), nb::arg("stream_ptr"));

    m.def("gated_delta_decode_fused", &gated_delta_decode_fused,
          "GatedDeltaNet decode with gate projections, gate math and q/k normalization folded in",
          nb::arg("mixed_qkv"), nb::arg("x"), nb::arg("w_a"), nb::arg("w_b"), nb::arg("dt_bias"), nb::arg("g_decay"),
          nb::arg("state"), nb::arg("out"), nb::arg("snapshots") = nb::none(),
          nb::arg("z"), nb::arg("norm_w"), nb::arg("eps"),
          nb::arg("key_dim"), nb::arg("num_key_heads"), nb::arg("scale"), nb::arg("stream_ptr"));

    m.def("deltanet_conv_step", &deltanet_conv_step,
          "Depthwise causal conv decode step with silu, in-place state update and rollback snapshots",
          nb::arg("proj"), nb::arg("conv_state"), nb::arg("conv_w"), nb::arg("conv_b") = nb::none(),
          nb::arg("conv_out"), nb::arg("conv_snaps") = nb::none(), nb::arg("stream_ptr"));

    m.def("sol_attn_plan", &sol_attn_plan_py,
          "Workspace dims, slot byte offsets and total bytes for this shape and token budget",
          nb::arg("batch"), nb::arg("seq_len"), nb::arg("num_heads"), nb::arg("token_aug") = 0);

    m.def("sol_attn", &sol_attn,
          "Sol-Attn training-free sparse attention (BF16 or FP16 in/out, head_dim 128)",
          nb::arg("q"), nb::arg("k"), nb::arg("v"), nb::arg("out"),
          nb::arg("workspace"),
          nb::arg("batch"), nb::arg("seq_len"), nb::arg("num_heads"),
          nb::arg("head_dim"),
          nb::arg("tau"), nb::arg("scale"),
          nb::arg("sink_start"), nb::arg("sink_end"),
          nb::arg("sink_q_start"), nb::arg("sink_q_end"),
          nb::arg("stream_ptr"),
          nb::arg("key_bias") = nb::none(),
          nb::arg("threshold") = nb::none(),
          nb::arg("block_len") = nb::none(),
          nb::arg("tail") = true, nb::arg("token_aug") = 0);

    m.def("sol_producer_begin", &sol_producer_begin_py,
          nb::arg("workspace"), nb::arg("batch"), nb::arg("seq_len"),
          nb::arg("num_heads"), nb::arg("stream_ptr"), nb::arg("token_aug") = 0);
    m.def("sol_producer_chunk", &sol_producer_chunk_py,
          nb::arg("workspace"), nb::arg("qkv"), nb::arg("fab"), nb::arg("qw"),
          nb::arg("kw"), nb::arg("kmean"), nb::arg("vscale"),
          nb::arg("rope_eps"), nb::arg("rot_dim"), nb::arg("t0"), nb::arg("m"),
          nb::arg("batch"), nb::arg("seq_len"), nb::arg("num_heads"),
          nb::arg("stream_ptr"), nb::arg("block_len") = nb::none(), nb::arg("token_aug") = 0);
    m.def("sol_attn_core", &sol_attn_core_py,
          nb::arg("workspace"), nb::arg("out"), nb::arg("vscale"),
          nb::arg("kmean_next"), nb::arg("vamax_out"),
          nb::arg("batch"), nb::arg("seq_len"), nb::arg("num_heads"),
          nb::arg("tau"), nb::arg("scale"),
          nb::arg("sink_start"), nb::arg("sink_end"),
          nb::arg("sink_q_start"), nb::arg("sink_q_end"), nb::arg("stream_ptr"),
          nb::arg("threshold") = nb::none(),
          nb::arg("block_len") = nb::none(),
          nb::arg("tail") = true, nb::arg("token_aug") = 0);

    m.def("flash_attention_decode", &flash_attention_decode,
          "Flash Attention decode over a fixed-capacity variable-length KV cache",
          nb::arg("q"), nb::arg("k"), nb::arg("v"), nb::arg("kv_lengths"),
          nb::arg("output"), nb::arg("softmax_lse"), nb::arg("softmax_lse_accum"),
          nb::arg("output_accum"), nb::arg("num_splits"), nb::arg("stream_ptr"));

    m.def("cutlass_fp16_conv3d", &cutlass_fp16_conv3d,
          "fp16-accumulate NDHWC conv3d with fused bias/residual; false when declined",
          nb::arg("x"), nb::arg("w"), nb::arg("bias"), nb::arg("residual"), nb::arg("out"),
          nb::arg("N"), nb::arg("D"), nb::arg("H"), nb::arg("W"), nb::arg("C"),
          nb::arg("K"), nb::arg("T"), nb::arg("R"), nb::arg("S"),
          nb::arg("sd"), nb::arg("sh"), nb::arg("sw"), nb::arg("stream_ptr"), nb::arg("config") = -1,
          nb::arg("xs_w") = 0, nb::arg("xs_h") = 0, nb::arg("xs_d") = 0, nb::arg("xs_n") = 0,
          nb::arg("os_w") = 0, nb::arg("os_h") = 0, nb::arg("os_d") = 0, nb::arg("os_n") = 0);

    m.def("group_norm_silu_pad3d", &group_norm_silu_pad3d,
          "Per-frame GroupNorm + SiLU + causal conv padding, NDHWC",
          nb::arg("x"), nb::arg("weight"), nb::arg("bias"), nb::arg("out"), nb::arg("workspace"),
          nb::arg("B"), nb::arg("C"), nb::arg("T"), nb::arg("H"), nb::arg("W"),
          nb::arg("num_groups"), nb::arg("eps"),
          nb::arg("left"), nb::arg("right"), nb::arg("top"), nb::arg("bottom"), nb::arg("front"),
          nb::arg("silu"), nb::arg("zero_pad"), nb::arg("dtype_code"), nb::arg("stream_ptr"));

    m.def("adaln", &adaln,
          "Fused AdaLN: layernorm(x) * (1 + scale) + shift",
          nb::arg("x"),
          nb::arg("scale"),
          nb::arg("shift"),
          nb::arg("out"),
          nb::arg("N"),
          nb::arg("D"),
          nb::arg("scale_group"),
          nb::arg("shift_group"),
          nb::arg("eps"),
          nb::arg("dtype_code"),
          nb::arg("stream_ptr"));

    m.def("rms_adaln", &rms_adaln,
          "Fused AdaLN: rmsnorm(x) * (1 + scale) + shift",
          nb::arg("x"),
          nb::arg("scale"),
          nb::arg("shift"),
          nb::arg("out"),
          nb::arg("N"),
          nb::arg("D"),
          nb::arg("scale_group"),
          nb::arg("shift_group"),
          nb::arg("eps"),
          nb::arg("dtype_code"),
          nb::arg("stream_ptr"));

    // Feature availability flag (computed at module load time)
    m.attr("HAS_CUBLASLT") = comfy::CublasLtRuntime::instance().is_available();

    m.attr("__nanobind__") = true;
    m.attr("__stable_abi__") = true;
}
